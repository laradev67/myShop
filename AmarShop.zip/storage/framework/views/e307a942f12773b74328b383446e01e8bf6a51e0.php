<?php $__env->startSection('content'); ?>

<section class="products">
  <div class="container">
    <div class="columns">
      <div class="column is-3">
        <?php echo $__env->make('partials.product-left-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
      <div class="column is-9">

        <b-notification type="is-success">
          Total <mark><?php echo e($products->count()); ?></mark> products are available in <?php echo e($category->name); ?> Category
        </b-notification>
        <?php echo $__env->make('partials.products_list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
    </div> <!-- End columns -->
  </div> <!-- End container -->



</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
 const app = new Vue({
  el: '#app',
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>