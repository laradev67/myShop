
<nav class="navbar m-b-5 is-primary is-fixed-top" role="navigation" aria-label="main navigation">
  <div class="container">

    <div class="navbar-brand">
      <a class="navbar-item" href="<?php echo e(url('/')); ?>">
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Amar Shop" width="112" height="50">
      </a>

      <div class="navbar-burger burger" data-target="navMenu">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>

    <div class="navbar-menu"  id="navMenu">
      <div class="navbar-start">
        <a href="<?php echo e(route('index')); ?>" class="navbar-item"> Home </a>
        

        <div class="navbar-item has-dropdown is-hoverable is-mega">
          <div class="navbar-link">
            Products
          </div>
          <div id="blogDropdown" class="navbar-dropdown">
            <div class="container is-fluid">
              <div class="columns">
                <div class="column">
                  <h1 class="title is-6 is-mega-menu-title"> Product Ads</h1>
                  <?php
                  $postproducts = App\Product::orderBy('id', 'desc')->where('publish_status', 1)->limit(4)->get();
                  $requestproducts = App\Productrequest::orderBy('id', 'desc')->where('publish_status', 1)->limit(5)->get();
                  ?>
                  <?php $__currentLoopData = $postproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <a class="navbar-item" href="<?php echo route('product.show', $product->slug); ?>">
                    <div class="navbar-content">
                      <div class="columns">
                        <div class="column is-3">
                          <?php $image = DB::table('product_images')->where('product_id', $product->id)->first(); ?>
                          <img src="<?php echo e(asset("images/products/$image->image")); ?>" alt="<?php echo e($product->title); ?>" style="width: 150px;">
                        </div>
                        <div class="column is-9">
                          <p><?php echo e($product->title); ?></p>
                          <p>
                            <small class="has-text-info">Posted <?php echo e(\Carbon\Carbon::parse($product->created_at)->diffForHumans()); ?></small>
                          </p>
                        </div>
                      </div>

                    </div>
                  </a>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                  <a href="<?php echo e(route('product.index')); ?>" class="navbar-item button is-full is-success"> More products to buy</a>
                </div>
                <div class="column">
                  <h1 class="title is-6 is-mega-menu-title">Product Requested</h1>

                  <?php $__currentLoopData = $requestproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <a class="navbar-item" href="<?php echo route('product.request_products.show', $product->slug); ?>">
                    <div class="navbar-content">
                      <div class="columns">
                        <div class="column is-3">
                          <?php if(($product->image == NULL) || ($product->image == "")): ?>
                          <img src="<?php echo e(asset("images/product_requests/default.png")); ?>" alt="<?php echo e($product->title); ?>" style="width:100px" >
                          <?php else: ?>
                          <img src="<?php echo e(asset("images/product_requests/$product->image")); ?>" alt="<?php echo e($product->title); ?>" style="width:100px">
                          <?php endif; ?>
                        </div>
                        <div class="column is-9">
                          <p><?php echo e($product->title); ?></p>
                          <p>
                            <small class="has-text-info">Posted <?php echo e(\Carbon\Carbon::parse($product->created_at)->diffForHumans()); ?></small>
                          </p>
                        </div>
                      </div>

                    </div>
                  </a>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  <a href="<?php echo e(route('product.request_products')); ?>" class="navbar-item button is-full is-success"> More products to sell</a>
                </div>
              </div>
            </div>
          </div>
        </div> <!-- End Mega Menu For Products-->

        <div class="navbar-item has-dropdown is-hoverable is-mega">
          <div class="navbar-link">
            Categories
          </div>
          <div id="blogDropdown" class="navbar-dropdown">
            <div class="container is-fluid">
              <b-tabs>
                <?php
                $categories = App\Category::orderBy('id', 'desc')->get();
                ?>

                <?php $i = 1; ?>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(($category->products()->count() > 0) && ($i <= 5)): ?>
                <?php $i++; ?>
                <b-tab-item label="<?php echo e($category->name); ?>">

                  <div class="columns">
                    <div class="column">
                      <h1 class="title is-6 is-mega-menu-title"> Product Ads</h1>
                      <?php
                      $postproducts = App\Product::orderBy('id', 'desc')->where('publish_status', 1)->where('category_id', $category->id)->limit(5)->get();
                      $requestproducts = App\Productrequest::orderBy('id', 'desc')->where('publish_status', 1)->where('category_id', $category->id)->limit(5)->get();
                      ?>
                      <?php $__currentLoopData = $postproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <a class="navbar-item" href="<?php echo route('product.show', $product->slug); ?>">
                        <div class="navbar-content">
                          <div class="columns">
                            <div class="column is-3">
                              <?php $image = DB::table('product_images')->where('product_id', $product->id)->first(); ?>
                              <img src="<?php echo e(asset("images/products/$image->image")); ?>" alt="<?php echo e($product->title); ?>" style="width: 150px;">
                            </div>
                            <div class="column is-9">
                              <p><?php echo e($product->title); ?></p>
                              <p>
                                <small class="has-text-info">Posted <?php echo e(\Carbon\Carbon::parse($product->created_at)->diffForHumans()); ?></small>
                              </p>
                            </div>
                          </div>

                        </div>
                      </a>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <div class="column">
                      <h1 class="title is-6 is-mega-menu-title">Product Requested</h1>

                      <?php $__currentLoopData = $requestproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <a class="navbar-item" href="<?php echo route('product.request_products.show', $product->slug); ?>">
                        <div class="navbar-content">
                          <div class="columns">
                            <div class="column is-3">
                              <?php if(($product->image == NULL) || ($product->image == "")): ?>
                              <img src="<?php echo e(asset("images/product_requests/default.png")); ?>" alt="<?php echo e($product->title); ?>" style="width:100px" >
                              <?php else: ?>
                              <img src="<?php echo e(asset("images/product_requests/$product->image")); ?>" alt="<?php echo e($product->title); ?>" style="width:100px">
                              <?php endif; ?>
                            </div>
                            <div class="column is-9">
                              <p><?php echo e($product->title); ?></p>
                              <p>
                                <small class="has-text-info">Posted <?php echo e(\Carbon\Carbon::parse($product->created_at)->diffForHumans()); ?></small>
                              </p>
                            </div>
                          </div>

                        </div>
                      </a>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                  </div>
                  <a href="<?php echo route('product.category.index', $category->slug); ?>" class="button is-full is-success">More in <?php echo e($category->name); ?> category</a>

                </b-tab-item>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <b-tab-item label="More">
                  <a href="<?php echo route('categories'); ?>" class="button is-full is-success"> See All Categories</a>
                </b-tab-item>
              </b-tabs>
            </div>
          </div>
        </div> <!-- End Mega Menu For Products Categories-->

        <div class="navbar-item has-dropdown is-hoverable is-mega">
          <div class="navbar-link">
            Brands
          </div>
          <div id="blogDropdown" class="navbar-dropdown">
            <div class="container is-fluid">
              <b-tabs>
                <?php
                $brands = App\Brand::orderBy('id', 'desc')->get();
                ?>

                <?php $i = 1; ?>
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(($brand->products()->count() > 0) && ($i <= 4)): ?>
                <?php $i++; ?>
                <b-tab-item label="<?php echo e($brand->name); ?>">

                  <div class="columns">
                    <div class="column">
                      <h1 class="title is-6 is-mega-menu-title"> Product Ads</h1>
                      <?php
                      $postproducts = App\Product::orderBy('id', 'desc')->where('publish_status', 1)->where('brand_id', $brand->id)->limit(3)->get();
                      $requestproducts = App\Productrequest::orderBy('id', 'desc')->where('publish_status', 1)->where('brand_id', $brand->id)->limit(3)->get();
                      ?>
                      <?php $__currentLoopData = $postproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <a class="navbar-item" href="<?php echo route('product.show', $product->slug); ?>">
                        <div class="navbar-content">
                          <div class="columns">
                            <div class="column is-3">
                              <?php $image = DB::table('product_images')->where('product_id', $product->id)->first(); ?>
                              <img src="<?php echo e(asset("images/products/$image->image")); ?>" alt="<?php echo e($product->title); ?>" style="width: 150px;">
                            </div>
                            <div class="column is-9">
                              <p><?php echo e($product->title); ?></p>
                              <p>
                                <small class="has-text-info">Posted <?php echo e(\Carbon\Carbon::parse($product->created_at)->diffForHumans()); ?></small>
                              </p>
                            </div>
                          </div>

                        </div>
                      </a>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <div class="column">
                      <h1 class="title is-6 is-mega-menu-title">Product Requested</h1>

                      <?php $__currentLoopData = $requestproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <a class="navbar-item" href="<?php echo route('product.request_products.show', $product->slug); ?>">
                        <div class="navbar-content">
                          <div class="columns">
                            <div class="column is-3">
                              <?php if(($product->image == NULL) || ($product->image == "")): ?>
                              <img src="<?php echo e(asset("images/product_requests/default.png")); ?>" alt="<?php echo e($product->title); ?>" style="width:100px" >
                              <?php else: ?>
                              <img src="<?php echo e(asset("images/product_requests/$product->image")); ?>" alt="<?php echo e($product->title); ?>" style="width:100px">
                              <?php endif; ?>
                            </div>
                            <div class="column is-9">
                              <p><?php echo e($product->title); ?></p>
                              <p>
                                <small class="has-text-info">Posted <?php echo e(\Carbon\Carbon::parse($product->created_at)->diffForHumans()); ?></small>
                              </p>
                            </div>
                          </div>

                        </div>
                      </a>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                  </div>
                  <a href="<?php echo route('product.brand.index', $brand->slug); ?>" class="button is-full is-success">More in <?php echo e($brand->name); ?> brand</a>

                </b-tab-item>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <b-tab-item label="More">
                  <a href="<?php echo route('brands'); ?>" class="button is-full is-success"> See All Brands</a>
                </b-tab-item>
              </b-tabs>
            </div>
          </div>
        </div> <!-- End Mega Menu For Products Categories-->

        <div class="navbar-end">

          <div class="navbar-item">
            <?php echo $__env->make('components/searchProduct', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          </div>
          <a class="navbar-item" href="<?php echo e(route('search')); ?>" title="">Advance Search</a>

          
            
              
              <a href="<?php echo e(route('cart')); ?>" class="navbar-item">
                <i class="fa fa-cart-size fa-cart-plus"></i>
                <span class="tag is-warning"><?php echo e(Cart::count()); ?></span>
              </a>
            
          




          <?php if(Auth::check()): ?>
          <?php
          $wishlist = App\Wishlist::where('user_id', Auth::user()->id);
          $notification = App\Notification::where('user_id', Auth::user()->id)->where('status', 0);
          ?>
          
          <div class="navbar-item has-dropdown is-hoverable">
            <a class="navbar-link">
              <?php echo e((Auth::check()) ? Auth::user()->name : ''); ?>

              <?php if( $notification->count() != 0): ?>
              <span class="tag is-warning"> <?php echo e($notification->count()); ?></span>
              <?php endif; ?>
              
            </a>

            <div class="navbar-dropdown">
                
              
              <a href="<?php echo e(route('user.show', Auth::user()->username)); ?>" class="navbar-item"><i class="fa fa-user"></i> &nbsp; Profile </a>

              <a href="<?php echo e(route('user.dashboard')); ?>" class="navbar-item"><i class="fa fa-user"></i> &nbsp; Dashboard </a>

              <a href="<?php echo e(route('product.create')); ?>" class="navbar-item"><i class="fa fa-cart-plus"></i> &nbsp; Post Sell Product </a>

              <a href="<?php echo e(route('product.request')); ?>" class="navbar-item"><i class="fa fa-cart-plus"></i> &nbsp; Request Sell Product </a>

              <a href="<?php echo e(route('notification')); ?>" class="navbar-item"><i class="fa fa-bell"></i> &nbsp; Notifications  <span class="tag is-warning"> <?php echo e($notification->count()); ?> </span> </a>


              <a href="<?php echo e(route('wishlist')); ?>" class="navbar-item"><i class="fa fa-bell"></i> &nbsp; Wishlists  <span class="tag is-warning"> <?php echo e($wishlist->count()); ?> </span> </a>

              <a  class="navbar-item" href="<?php echo e(route('logout')); ?>"
              onclick="event.preventDefault();
              document.getElementById('logout-form').submit();">
              <i class="fa fa-sign-out"></i>
              &nbsp; Logout
            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
              <?php echo e(csrf_field()); ?>

            </form>



          </div>
        </div>
        <?php else: ?>
        


      <div class="navbar-item has-dropdown is-hoverable">
        <div class="navbar-link">
          Login
        </div>
        <div id="" class="navbar-dropdown">
          <?php echo $__env->make('components.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

      </div>

      <a href="<?php echo e(route('register')); ?>" class="navbar-item">Sign Up</a>

      <?php endif; ?>

    </div>

  </div>  <!-- Nav menu -->


</div> <!-- Nav Container -->
</nav>
