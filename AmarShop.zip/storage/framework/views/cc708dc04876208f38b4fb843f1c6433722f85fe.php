<?php $__env->startSection('content'); ?>
<div class="card">
	<header>
		<div class="card-header card-header-title">
			Update Shipping Address
		</div>
	</header><!-- /header -->
	<div class="card-content">
		<form action="<?php echo e(route('user.change_shipping_address')); ?>" method="post" enctype="multipart/form-data">
			<?php echo e(csrf_field()); ?>

			<input type="hidden" name="shipping_id" value="<?php echo e(($user->shipping_address)? $user->shipping_address->id : ''); ?>">
			<b-field grouped>
				<b-field label="Name" expanded>
					<b-field>
						<b-input id="shipping_name" name="name" placeholder="Enter name for shipping product" value="<?php echo e(($user->shipping_address)? $user->shipping_address->name : ''); ?>" required v-if=""></b-input>
					</b-field>
				</b-field>
				<b-field label="Email (Optional)" expanded>
					<b-input placeholder="some@email.com" type="email" name="email" value="<?php echo e(($user->shipping_address)? $user->shipping_address->email : ''); ?>"></b-input>
				</b-field>
			</b-field>

			<b-field grouped>
				<b-field label="Division" expanded>
					<div class="control">
						<div class="select">
							<select placeholder="Select a division" name="division_id" v-on:change="onChangeDivision" required expanded>

								<option value="">Select a division please</option>
								<?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($user->shipping_address): ?>
								<?php if($division->id == $user->shipping_address->division_id): ?>
								<option value="<?php echo e($division->id); ?>" selected><?php echo e($division->name); ?></option>
								<?php endif; ?>
								<?php else: ?>
								<option value="<?php echo e($division->id); ?>"><?php echo e($division->name); ?></option>
								<?php endif; ?>
								
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
					</div>
				</b-field>
				<b-field label="District" expanded>
					<div class="control">
						<div class="select">
							<select placeholder="Select a district" v-on:change="onChangeDistricts" name="district_id" required  expanded  v-model="selectedDistrict">
								<?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($user->shipping_address): ?>
								<?php if($district->id == $user->shipping_address->district_id): ?>
								<option value="<?php echo e($district->id); ?>" selected><?php echo e($district->name); ?></option>
								<?php endif; ?>
								<?php else: ?>
								
								<option value="<?php echo e($district->id); ?>"><?php echo e($district->name); ?></option>
								<?php endif; ?>
								
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</option>
						</select>
					</div>
				</div>

			</b-field>
			<b-field label="Upazilla" expanded>
				<div class="control">
					<div class="select">
						<select placeholder="Select a upazilla" name="upazilla_id" required expanded v-model="selectedUpazilla">
							<?php $__currentLoopData = $upazillas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upazilla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($user->shipping_address): ?>
							<?php if($upazilla->id == $user->shipping_address->upazilla_id): ?>
							<option value="<?php echo e($upazilla->id); ?>" selected><?php echo e($upazilla->name); ?></option>
							<?php endif; ?>
							<?php else: ?>
							
							<option value="<?php echo e($upazilla->id); ?>"><?php echo e($upazilla->name); ?></option>
							<?php endif; ?>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</option>
					</select>
				</div>
			</div>


		</b-field>
	</b-field>
	<b-field grouped>
		<b-field label="Street Address 1" expanded>
			<b-input placeholder="Street Address" name="street_address1" maxlength="100" required value="<?php echo e(($user->shipping_address)? $user->shipping_address->street_address1 : ''); ?>"></b-input>
		</b-field>
		<b-field label="Street Address 2 (Optional)" expanded>
			<b-input placeholder="Street Address" name="street_address2" maxlength="100" value="<?php echo e(($user->shipping_address)? $user->shipping_address->street_address2 : ''); ?>"></b-input>
		</b-field>
	</b-field>
	<b-field grouped>

		<b-field label="Phone Number" expanded>
			<b-input placeholder="Phone Number" name="phone" maxlength="15" required value="<?php echo e(($user->shipping_address)? $user->shipping_address->phone : ''); ?>"></b-input>
		</b-field>    
		<b-field label="Courier Address" expanded>
			<b-input placeholder="Courier Address" name="courier_address" maxlength="150" required value="<?php echo e(($user->shipping_address)? $user->shipping_address->courier_address : ''); ?>"></b-input>
		</b-field>

	</b-field>

	<button type="submit" class="button is-success">Update</button>

</form>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
	const app = new Vue({
		el: '#app',
		data:{
			divisions : [<?php echo $divisions; ?>],
			districts : [<?php echo $districts; ?>],
			upazillas : [<?php echo $upazillas; ?>],
		},
		methods:{

			onChangeDivision: function(event){
				var division_id = event.srcElement.value
        //Find the districts by this division and change the districts array
        axios.get("/api/get_districts/"+division_id)
        .then(response => {
        	this.districts = response.data
        })
    },
    onChangeDistricts: function(event){
    	var district_id = event.srcElement.value
        //Find the districts by this division and change the districts array
        axios.get("/api/get_upazillas/"+district_id)
        .then(response => {
        	this.upazillas = response.data
        })
    },

}
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user_dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>