<?php $__env->startSection('stylesheets'); ?>
<style>
.hero.is-success {
    background: #F2F6FA;
}
.hero .nav, .hero.is-success .nav {
    -webkit-box-shadow: none;
    box-shadow: none;
}
.box {
    margin-top: 1rem;
}
input {
    font-weight: 300;
}
p {
    font-weight: 700;
}
p.subtitle {
    padding-top: 1rem;
}
</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<section class="hero is-success">
    <div class="hero-body">
      <div class="container has-text-centered">
        <div class="column is-4 is-offset-4">
            <div class="card">
                <div class="card-header card-header-title">Reset Password</div>
                <div class="card-block p-l-10 p-r-10">
                    <?php if(session('status')): ?>
                    <b-notification type="is-info" has-icon>
                        <?php echo e(session('status')); ?>

                    </b-notification>
                    <?php endif; ?>
                    
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="input" name="email" value="<?php echo e(old('email')); ?>" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="button is-primary m-t-10 m-b-10">
                                Send Password Reset Link
                            </button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
 const app = new Vue({
  el: '#app',
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>