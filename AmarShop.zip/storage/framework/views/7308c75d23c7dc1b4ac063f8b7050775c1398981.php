<?php $__env->startSection('title'); ?>
Edit | User Info <?php echo e($user->name); ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('stylesheets'); ?>
<style type="text/css">
#map-canvas {
  width: 300px;
  height: 250px;
  border: 1px solid blueviolet;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section class="hero">
  <div class="hero-body">
    <div class="container">
      <div class="columns">
        <div class="column is-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title p-l-10 p-t-10 p-b-10">Edit My Account</h3>
            </div>
            <div class="card-content ">
              <form action="<?php echo e(route('user.update', Auth::user()->username)); ?>" method="POST" class="p-b-20" enctype="multipart/form-data">

                <?php echo e(csrf_field()); ?>


                <div class="columns">
                  <div class="column is-7">

                    <div class="field is-horizontal">
                      <div class="field-label is-normal">
                        <label class="label">Account Type</label>
                      </div>

                      <div class="field-body">
                        <b-field>
                          <div class="select">
                            <select class="is-fullwidth" name="is_company" required>
                              <option value="0" <?php echo e($user->is_company == 0 ? 'selected': ''); ?>>As a user</option>
                              <option value="1" <?php echo e($user->is_company == 1 ? 'selected': ''); ?>>As a Company</option>
                            </select>
                          </div>
                        </b-field>
                      </div> <!--End Field Body -->
                    </div> <!--End Field Horizontal-->


                    <div class="field is-horizontal">
                      <div class="field-label is-normal">
                        <label class="label">Name</label>
                      </div>

                      <div class="field-body">
                        <b-field>
                          <b-input placeholder="Name" name="name" icon="user" required maxlength=30 value="<?php echo e($user->name); ?>"></b-input>
                        </b-field>
                      </div> <!--End Field Body -->
                    </div> <!--End Field Horizontal-->




                    <div class="field is-horizontal">

                      <div class="field-label is-normal">
                        <label class="label">Email</label>
                      </div>
                      <div class="field-body">
                        <b-field>
                          <b-input placeholder="Primary Email" type="email" name="email" icon="envelope" is-expanded="true" required  value="<?php echo e($user->email); ?>"></b-input>
                        </b-field>
                      </div> <!--End Field Body -->
                    </div> <!--End Field Horizontal-->


                    <div class="field is-horizontal">
                      <div class="field-label is-normal">
                        <label class="label">Phone No</label>
                      </div>

                      <div class="field-body">
                        <div class="field-body">
                          <b-field>
                            <b-input placeholder="01951233084" type="text" name="phone" icon="phone" is-expanded="true" required  value="<?php echo e($user->phone); ?>"></b-input>
                          </b-field>
                        </div> <!--End Field Body -->
                      </div> <!--End Field Body -->
                    </div> <!--End Field Horizontal-->


                    <div class="field is-horizontal">
                      <div class="field-label is-normal">
                        <label class="label">Division / District</label>
                      </div>

                      <div class="field-body">
                        <b-field>
                          <select class="is-fullwidth input" name="division_id" required>
                            <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($division->id == $user->division_id): ?>
                            <option value="<?php echo e($division->id); ?>" selected><?php echo e($division->name); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($division->id); ?>"><?php echo e($division->name); ?></option>
                            <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </b-field>
                        <b-field>
                          <select class="is-fullwidth input" name="district_id" required>
                            <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($district->id == $user->district_id): ?>
                            <option value="<?php echo e($district->id); ?>" selected><?php echo e($district->name); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($district->id); ?>"><?php echo e($district->name); ?></option>
                            <?php endif; ?>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </b-field>

                      </div> <!--End Field Body -->
                    </div> <!--End Field Horizontal-->


                    <div class="field is-horizontal">
                      <div class="field-label is-normal">
                        <label class="label">Street</label>
                      </div>

                      <div class="field-body">
                        <b-field>
                          <b-input placeholder="Street Address" type="text" name="street_address" icon="address-book" maxLength=100 value="<?php echo e($user->street_address); ?>"></b-input>
                        </b-field>
                      </div> <!--End Field Body -->
                    </div> <!--End Field Horizontal-->

                    <div class="field is-horizontal">
                      <div class="field-label is-normal">
                        <label class="label">Password</label>
                      </div>

                      <div class="field-body">
                        <b-field>
                          <b-input placeholder="Password" type="password" name="password" icon="lock" required password-reveal></b-input>
                        </b-field>
                        <b-field>
                          <b-input placeholder="Confirm Password" type="password" name="password_confirmation" icon="lock" required password-reveal></b-input>
                        </b-field>
                      </div> <!--End Field Body -->
                    </div> <!--End Field Horizontal-->



                    <div class="field-body is-centered">
                      <p class="control is-centered">
                        <button class="button is-primary" type="submit">Register</button>
                      </p>
                    </div> <!--End Field Body -->
                  </div>
                  <div class="column is-5" style="border-left: 1px solid gray">

                    <div class="field is-horizontal">
                      <div class="field-label is-normal">
                        <label class="label">Website (Optional)</label>
                      </div>
                      <div class="field-body">
                        <b-field>
                          <b-input placeholder="Primary Email" type="url" name="website" icon="rss_square" is-expanded="true" required  value="<?php echo e($user->website); ?>"></b-input>
                        </b-field>
                      </div> <!--End Field Body -->
                    </div> <!--End Field Horizontal-->

                    <div class="field is-horizontal">
                      <div class="field-label is-normal">
                        <label class="label">Profile (Previous)</label>
                      </div>
                      <div class="field-body">
                        <img src='<?php echo e(($user->image != null) ? "images/users/$user->image" : ""); ?>' style="width: 100px; border: 1px solid blueviolet;">
                      </div> <!--End Field Body -->
                    </div> <!--End Field Horizontal-->

                    <div class="field is-horizontal">
                      <div class="field-label is-normal">
                        <label class="label">Profile(New) (Optional)</label>
                      </div>
                      <div class="field-body">
                        <b-field>
                          <b-input type="file" name="website" icon="rss_square" is-expanded="true"></b-input>
                        </b-field>
                      </div> <!--End Field Body -->
                    </div> <!--End Field Horizontal-->

                    <div class="field is-horizontal">
                      <div class="field-label is-normal">
                        <label class="label">Location (Search)</label>
                      </div>
                      <div class="field-body">
                        <b-field>
                          <b-input type="text" id="searchmap" name="searchmap" icon="search"  is-expanded="true"></b-input>
                        </b-field>
                        
                      </div> <!--End Field Body -->
                    </div> <!--End Field Horizontal-->

                    <div class="field is-horizontal">
                      <div class="field-label is-normal">
                        <label class="label">Location (Optional)</label>
                      </div>
                      <div class="field-body">
                        <div id="map-canvas"></div>
                      </div> <!--End Field Body -->
                    </div> <!--End Field Horizontal-->


                  </div>
                </div>

              </form> <!--End User Registration Form -->

            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</section>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<script>
  var map;
  function initMap() {
    map = new google.maps.Map(document.getElementById('map-canvas'), {
      center: 
      {
        lat: 22.464814,
        lng: 90.3813789
      },
      zoom: 15
    });

 

    marker = new google.maps.Marker({
      position: 
      {
        lat: 22.464814,
        lng: 90.3813789
      },
      map: map,
      draggable: true
    });

   var searchBox = new google.maps.places.SearchBox(document.getElementById('searchmap'));
   google.maps.event.addListener(searchBox, 'places_changed' function(){
      var places = searchBox.getPlaces();
      var bounds = new google.maps.LatLngBounds();

      for ($i = 0; $place = $places[$i] ; $i++)
      {
        bounds.extend(place.geometry.location);
        marker.setPosition(place.geometry.location);
        
      }
      map.fitBounds(bounds);
      map.setZoom(15);
      
   })


  }

  

</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC4f01TWPmCIDs9ZbZf7YJyaQo6JhttWRE&callback=initMap" async defer></script>


<script type="text/javascript">
  const app = new Vue({
    el: '#app',
    data:{

    },
    methods:{

    }
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>