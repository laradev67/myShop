<nav class="navbar m-b-50 is-primary" role="navigation" aria-label="main navigation">
  <div class="container">
    <div class="navbar-brand">
      <a class="navbar-item" href="<?php echo e(url('/')); ?>">
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Bulma: a modern CSS framework based on Flexbox" width="112" height="50">
      </a>


      <div class="navbar-burger burger" data-target="navMenu">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
    <div class="navbar-menu"  id="navMenu">
      <div class="navbar-start">
        <a href="<?php echo e(route('home')); ?>" class="navbar-item"> Home </a>
        <a href="<?php echo e(route('home')); ?>" class="navbar-item"> Blog </a>
        <a href="<?php echo e(route('home')); ?>" class="navbar-item"> Forum </a>
        <a href="<?php echo e(route('home')); ?>" class="navbar-item"> About </a>
        <a href="<?php echo e(route('home')); ?>" class="navbar-item"> Contact </a>

        <div class="navbar-item has-dropdown is-hoverable">
          <a class="navbar-link">
            Top Categories
          </a>

          <div class="navbar-dropdown">
            <a href="<?php echo e(route('home')); ?>" class="navbar-item"> Home </a>
            <a href="<?php echo e(route('home')); ?>" class="navbar-item"> Blog </a>
            <a href="<?php echo e(route('home')); ?>" class="navbar-item"> Forum </a>
          </div>
        </div>
      </div>
      <div class="navbar-end">

        <?php if(!Auth::guest()): ?>
        <div class="navbar-item has-dropdown is-hoverable">
          <a class="navbar-link">
            Hello Maniruzzaman Akash
          </a>

          <div class="navbar-dropdown">
            <a href="<?php echo e(route('home')); ?>" class="navbar-item"> <span class="icon"><i class="fa fa-fw fa-user m-r-15"></i></span> Profile </a>
            <a href="<?php echo e(route('home')); ?>" class="navbar-item"> <span class="icon"><i class="fa fa-fw fa-bell m-r-15"></i></span> Notifications </a>
            <a href="<?php echo e(route('home')); ?>" class="navbar-item"> <span class="icon"><i class="fa fa-fw fa-cog m-r-15"></i></span> Settings </a>
            <hr class="navbar-divider">
            <a href="<?php echo e(route('home')); ?>" class="navbar-item"> <span class="icon"><i class="fa fa-fw fa-sign-out m-r-15"></i></span> Logout </a>
          </div>
        </div>
        <?php else: ?>
          <a href="<?php echo e(route('login')); ?>" class="navbar-item">Login</a>
          <a href="<?php echo e(route('register')); ?>" class="navbar-item">Join Our Community</a>
        <?php endif; ?>


      </div>
    </div> <!--End Navbar Menu-->


  </div>
</nav>