<?php $__env->startSection('content'); ?>

<nav class="breadcrumb" aria-label="breadcrumbs">
  <ul>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>">Admin Panel</a></li>
    <li class="is-active"><a href="#" aria-current="page">Dashboard</a></li>
  </ul>
</nav>


<section class="hero is-info welcome is-small">
  <div class="hero-body">
    <div class="container">
      <h1 class="title">
        Hello, Admin.
      </h1>
      <h2 class="subtitle">
        I hope you are having a great day!
      </h2>
    </div>
  </div>
</section>

<?php
$total_products = $unpublished_products->count() + $published_products->count();
?>

<section class="info-tiles">
  <div class="tile is-ancestor has-text-centered">
    <div class="tile is-parent">
      <article class="tile is-child box">
        <p class="title"><?php echo e($users->count()); ?></p>
        <p class="subtitle">Users</p>
      </article>
    </div>
    <div class="tile is-parent">
      <article class="tile is-child box">
        <p class="title"><?php echo e($companies->count()); ?></p>
        <p class="subtitle">Companies</p>
      </article>
    </div>
    <div class="tile is-parent">
      <article class="tile is-child box">
        <p class="title"><?php echo e($total_products); ?></p>
        <p class="subtitle">Products</p>
      </article>
    </div>
    <div class="tile is-parent">
      <article class="tile is-child box">
        <p class="title"><?php echo e($order_complete->count() + $order_uncomplete->count()); ?></p>
        <p class="subtitle">Orders</p>
      </article>
    </div>
  </div>
</section>

<section class="content m-t-30">

  <h2>All Sections</h2>
  <div class="tile is-ancestor has-text-centered">
    <div class="tile is-parent">
      <article class="tile is-child box is-danger">

        <p class="title"><?php echo e($order_complete->count() + $order_uncomplete->count()); ?> Total Orders</p>
        <p class="subtitle has-text-danger"><?php echo e($order_uncomplete->count()); ?> Uncomplete</p>
        <p class="subtitle has-text-success"><?php echo e($order_complete->count()); ?> Completed</p>
        <p class="subtitle"><a href="<?php echo e(route('admin.order')); ?>" class="button is-primary is-inline">Manage</a></p>
      </article>
    </div>
    <div class="tile is-parent">
      <article class="tile is-child box is-danger">

        <p class="title"><?php echo e($total_products); ?> Total Products</p>
        <p class="subtitle has-text-danger"><?php echo e($unpublished_products->count()); ?> Unpublished</p>
        <p class="subtitle has-text-success"><?php echo e($published_products->count()); ?> Published</p>
        <p class="subtitle"><a href="<?php echo e(route('admin.product.index')); ?>" class="button is-primary is-inline">Manage</a></p>
      </article>
    </div>
    <div class="tile is-parent">
      <article class="tile is-child box is-danger">
        <p class="title"><?php echo e($users->count() + $companies->count()); ?> Total Customers</p>
        <p class="subtitle has-text-info"><?php echo e($users->count()); ?> Users</p>
        <p class="subtitle has-text-warning"><?php echo e($companies->count()); ?> Companies</p>
        <p class="subtitle"><a href="<?php echo e(route('admin.user')); ?>" class="button is-primary is-inline">Manage</a></p>
      </article>
    </div>
  </div>
  
</section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
 const app = new Vue({
  el: '#app',
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>