<?php $__env->startSection('content'); ?>
<div class="card">
	<header>
		<div class="card-header card-header-title">
			Dashboard
		</div>
	</header><!-- /header -->
	<div class="card-content">
		<h3>Welcome To your Dashboard Panel <mark><?php echo e(Auth::user()->name); ?></mark></h3>
		<hr />
		<p>Here you can manage all of your customer orders, your products, your informations and so on... !!! </p>
		<p class="has-text-centered">Cheers ...!!!!</p>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
	const app = new Vue({
		el: '#app',
		data:{
		},
		methods:{

		}
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user_dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>