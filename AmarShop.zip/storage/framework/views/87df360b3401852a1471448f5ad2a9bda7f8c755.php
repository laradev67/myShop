<?php $__env->startSection('content'); ?>

<section class="hero m-b-5 p-b-30">
  <div class="container">
    <p class="section-title m-b-30">Get products from the Brands</p>
    <div class="columns is-multiline is-mobile is-centered">
      <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($brand->products()->count() > 0 ): ?>
          <div class="column is-info is-3">
            <div class="brand has-text-centered link-bigger-transition">
              <a href="<?php echo route('product.brand.index', $brand->slug); ?>" class="link-full-display link-div-big is-in has-text-danger">
                <img src="<?php echo e(asset("images/brands/$brand->image")); ?>" alt="">
                <br />
                <?php echo e($brand->name); ?>

              </a>
            </div>
          </div>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
  </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
  <script>
  const app = new Vue({
    el: '#app',
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>