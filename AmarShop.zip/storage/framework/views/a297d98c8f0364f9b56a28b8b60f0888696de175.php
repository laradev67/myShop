<?php $__env->startSection('title'); ?>
Verification User | Amar Shop
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section class="hero">
  <div class="hero-body">
    <div class="container">
      <div class="content">
        <div class="card">
          <div class="card-header">
            <h2 class="card-title p-10">Verify Email Address</h2>

          </div>
          <div class="card-block">
            <div class="container p-10">


              <?php if(( Session::has('success')) || (Session::has('already_added')) ): ?>
              <b-notification type="is-success">
                
                <p>You are verified successfully !! Please Login Now <a href="<?php echo e(route('login')); ?>" class="button is-primary">Login</a></p>
              </b-notification>
              <?php endif; ?>

              <?php if( Session::has('error') ): ?>
              
                
                <p>You are not verified</p>
                <p>If you haven't receive any verification mail yet, then please type your email in the field and we'll resend the verification mail..</p>
                <form method="post" action="<?php echo e(route('verification.send')); ?>" class="form-inline">
                  <?php echo e(csrf_field()); ?>

                  <input type="email" name="email" class="input" placeholder="Your Email" value="<?php echo e(Auth::check() ? Auth::user()->email : ''); ?>"><br /><br />
                  <button type="submit" class="button is-info">Send Verification Mail</button>
                </form>
              
              <?php endif; ?>



              

            </div>
          </div>
        </div>

      </div>
      
    </div>
  </div>
</section>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>

  const app = new Vue({
    el: '#app',
    data:{

    },
    methods:{

    }
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>