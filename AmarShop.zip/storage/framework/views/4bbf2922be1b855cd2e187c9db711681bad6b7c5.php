<aside>
	<div class="sidebar">

		<div class="widget">
			<nav class="panel">
				<p class="panel-heading">
					Search Any Products
				</p>
				<div class="panel-block">
					<?php echo $__env->make('components/searchProduct', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>


			</nav>
		</div>

		<div class="widget">
			<nav class="panel">
				<p class="panel-heading">
					Product By Divisions
				</p>

				<?php $divisions = DB::table('divisions')->get(); ?>
				<?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<a class="<?php echo e((Request::is("division/$division->slug/products")) ? 'active' : ''); ?> panel-block" href="<?php echo route('product.division.index', $division->slug); ?>">
						<span class="panel-icon">
							
							<img src='<?php echo asset("images/divisions/$division->image"); ?>'>
						</span>
						<?php echo e($division->name); ?>

					</a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</nav>
		</div>


		<div class="widget">
			<nav class="panel">
				<p class="panel-heading is-primary">
					Product By Categories
				</p>

				<?php $categories = DB::table('categories')->get(); ?>
				<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<a class="<?php echo e((Request::is("category/$category->slug/products")) ? 'active' : ''); ?> panel-block" href="<?php echo route('product.category.index', $category->slug); ?>">
						<span class="panel-icon">
							<img src='<?php echo asset("images/categories/$category->image"); ?>'>
						</span>
						<?php echo e($category->name); ?>

					</a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</nav>
		</div>

		<div class="widget">
			<nav class="panel">
				<p class="panel-heading">
					Product By Top Brand
				</p>

				<?php $brands = DB::table('brands')->get(); ?>
				<?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<a class="<?php echo e((Request::is("brand/$brand->slug/products")) ? 'active' : ''); ?> panel-block" href="<?php echo route('product.brand.index', $brand->slug); ?>">
						<span class="panel-icon">
							<img src='<?php echo asset("images/brands/$brand->image"); ?>'>
						</span>
						<?php echo e($brand->name); ?>

					</a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</nav>
		</div>

	</div>
</aside>
