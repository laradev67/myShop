<?php
  // require_once 'app/Functions/Info.php';
?>

<?php $__env->startSection('title'); ?>
Cart Page | Amar Shop
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section class="carts">
  <div class="container content">
    <h2>Cart Items</h2>
    <table class="table is-fullwidth">
      <thead>
        <tr>
          <th>Product</th>
          <th>Thumbnail</th>
          <th>Company/User</th>
          <th>Size | Quantity</th>
          <th>Price</th>
          <th>Subtotal</th>
          <th width="10%">Action</th>
        </tr>
      </thead>

      <tbody>

        <?php $__empty_1 = true; $__currentLoopData = $cart_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        
        <tr>
          <td>
            <p><a href="<?php echo e(route('product.show', get_product_slug($row->id))); ?>"><strong><?php echo e($row->name); ?></strong></a></p>
          </td>
          <td>
            <img src='<?php echo e(asset("images/products/".get_product_first_image($row->id))); ?>' class="image" style="width: 100px">
          </td>
          <td>
            <p><a href="<?php echo e(route('user.show', get_user_or_company($row->id)->username)); ?>"><?php echo e(get_user_or_company($row->id)->name); ?></a></p>
          </td>
          <td>
            <form class="form-inline" action="<?php echo e(route('cart.update', $row->rowId)); ?>" method="POST">
              <?php echo e(csrf_field()); ?>


              <?php if($row->options->has('size')): ?>
              <select name="size" class="select">
                <option value="Small" <?php echo e(($row->options->size == 'Small') ? 'selected' : ''); ?>>Small</option>
                <option value="Medium" <?php echo e(($row->options->size == 'Medium') ? 'selected' : ''); ?>>Medium</option>
                <option value="Large" <?php echo e(($row->options->size == 'Large') ? 'selected' : ''); ?>>Large</option>
                <option value="Extra Large" <?php echo e(($row->options->size == 'Extra Large') ? 'selected' : ''); ?>>Extra Large</option>
                
              </select>
              <?php endif; ?>

              <input type="number" value="<?php echo e($row->qty); ?>" class="input" name="qty" min="1" />
              <input type="submit" value="Update" class="button is-success is-small">
            </form>
          </td>



          <td>৳ <?php echo e($row->price); ?></td>
          <td>৳ <?php echo e($row->total); ?></td>
          <td>

            <a href="<?php echo e(route('product.show', get_product_slug($row->id))); ?>" class="button is-info is-small"><i class="fa fa-eye"></i></a>
            <form class="form-inline" action="<?php echo e(route('cart.destroy', $row->rowId)); ?>" method="POST" onsubmit="return confirm('Do you want to remove product from cart ?')">
              <?php echo e(csrf_field()); ?>

              <input type="submit" value="Delete" class="button is-danger is-small">
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="4">No Item in the cart..!! <br /> <br /> Add a Product to cart list <a href="<?php echo e(route('product.index')); ?>" class="button is-info">Products</a></td>
        </tr>
        <?php endif; ?>

        <tfoot>
          <tr>
            <td colspan="4"></td>
            <td><mark> <?php echo e(Cart::count()); ?></mark> Item</td>
            <td>
              Total - <mark>৳ <?php echo e(Cart::total()); ?></mark>
            </td>

            <td>
              <a href="<?php echo e(route('checkout')); ?>" class="button is-warning is-large">Checkout</td>
            </tr>
          </tfoot>


        </tbody>
      </table>
      <b-message type="is-info">
        <strong class="has-text-danger">Note : </strong>
        Same company products will take low shipping costs. Multiple company products will take more shipping cost for each company. <br />
        <strong class="has-text-warning">Also.. </strong>If you choose multiple company products then you may get product from different company at different day..!!
      </b-message>
    </div> <!-- End container -->
  </section>

  <?php $__env->stopSection(); ?>


  <?php $__env->startSection('scripts'); ?>
  <script>
   const app = new Vue({
    el: '#app',
    data:{
    },
    methods:{

    }
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>