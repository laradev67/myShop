<?php $__env->startSection('title'); ?>
Login | Amar Shop
<?php $__env->stopSection(); ?>

<?php $__env->startSection('stylesheets'); ?>
<style>
.hero.is-success {
    background: #F2F6FA;
}
.hero .nav, .hero.is-success .nav {
    -webkit-box-shadow: none;
    box-shadow: none;
}
.box {
    margin-top: 5rem;
}
.avatar {
    margin-top: -70px;
    padding-bottom: 20px;
}
.avatar img {
    padding: 5px;
    background: #fff;
    border-radius: 50%;
    -webkit-box-shadow: 0 2px 3px rgba(10,10,10,.1), 0 0 0 1px rgba(10,10,10,.1);
    box-shadow: 0 2px 3px rgba(10,10,10,.1), 0 0 0 1px rgba(10,10,10,.1);
    width: 120px;
}
input {
    font-weight: 300;
}
p {
    font-weight: 700;
}
p.subtitle {
    padding-top: 1rem;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<section class="hero is-success">
    <div class="hero-body">
      <div class="container has-text-centered">
        <div class="column is-4 is-offset-4">
            <h3 class="title has-text-grey">Login As Company</h3>
            <div class="box">
                <figure class="avatar">
                  <img src="<?php echo e(asset('images/logo.png')); ?>">
              </figure>
              <form action="<?php echo e(route('company.login.submit')); ?>" method="POST">
                  <?php echo e(csrf_field()); ?>


                  <b-field>
                    <b-input placeholder="Email" type="email" name="email" required></b-input>
                </b-field>

                <b-field label="Password">
                    <b-input type="password" required password-reveal name="password"></b-input>
                </b-field>


                <div class="field">
                    <b-checkbox name="remember" value="<?php echo e(old('remember')); ?>">Remember Me</b-checkbox>
                </div>

                <div class="buttons">
                    <button type="submit" class="button is-large is-primary is-outlined is-fullwidth">Login</button>
                </div>
            </form>
        </div>

    </div>
</div>
</div>
</section>




<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
 const app = new Vue({
  el: '#app',
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>