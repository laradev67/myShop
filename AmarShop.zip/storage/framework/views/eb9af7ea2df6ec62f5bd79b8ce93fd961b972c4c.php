<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" class="has-navbar-fixed-top">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>
        <?php echo $__env->yieldContent('title', 'Amar Shop User Dashboard | A Place to shop everything, sell everything'); ?>
    </title>
    
    

    <!-- Styles -->
    <link href="<?php echo e(url('css/app.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('stylesheets'); ?>
</head>
<body>
    <div id="app">
        <?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div v-cloak class="m-t-25">
            <div class="has-text-centered loading v-cloak--inline">
                <h1 style="margin-top: 10%; margin-bottom: 10%; background: #fff;">
                  <i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i>
                  <span class="sr-only">Loading...</span>
              </h1>
          </div>
          <div class="v-cloak--hidden">
            <?php echo $__env->make('components.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="container">


                <div class="columns m-t-10">
                    <div class="column is-4">
                        <div class="navigationbar">
                            <nav class="panel">
                              <p class="panel-heading">
                                Dashboard Actions
                            </p>
                            <a class="panel-block <?php echo e((Route::current()->getName() == "user.dashboard") ? 'is-active' : 'null'); ?>" href="<?php echo e(route('user.dashboard')); ?>">
                                <span class="panel-icon"> <i class="fa fa-dashboard"></i> </span>
                                Dashboard
                            </a>
                            <a class="panel-block  <?php echo e((Route::current()->getName() == "user.update_profile") ? 'is-active' : 'null'); ?>" href="<?php echo e(route('user.update_profile')); ?>">
                                <span class="panel-icon"> <i class="fa fa-user"></i> </span>
                                Update Profile
                            </a>
                            <a class="panel-block  <?php echo e((Route::current()->getName() == "user.change_shipping_address") ? 'is-active' : 'null'); ?>" href="<?php echo e(route('user.change_shipping_address')); ?>">
                                <span class="panel-icon"> <i class="fa fa-cart-plus"></i> </span>
                                Update Shipping Address
                            </a>
                            <a class="panel-block <?php echo e((Route::current()->getName() == "user.manage_orders") ? 'is-active' : 'null'); ?>" href="<?php echo e(route('user.manage_orders')); ?>">
                                <span class="panel-icon"> <i class="fa fa-bell"></i> </span>
                                Manage Orders
                            </a>
                        </nav>
                    </div>
                </div>
                <div class="column is-8">
                    <?php echo $__env->yieldContent('content'); ?> 
                </div>
            </div><!-- End Columns -->
        </div> <!-- End Container -->
        <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>


</div>
<script src="<?php echo e(url('js/app.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
