<?php $__env->startSection('content'); ?>

<section class="hero m-b-5 p-b-30">
  <div class="container">
    <p class="section-title m-b-30">Get products from the categories</p>
    <div class="columns is-multiline is-mobile is-centered">
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($category->products()->count() > 0 ): ?>
          <div class="column is-info is-3">
            <div class="category has-text-centered link-bigger-transition">
              <a href="<?php echo route('product.category.index', $category->slug); ?>" class="link-full-display link-div-big is-in has-text-danger">
                <img src="<?php echo e(asset("images/categories/$category->image")); ?>" alt="">
                <br />
                <?php echo e($category->name); ?>

              </a>
            </div>
          </div>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
  </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
  <script>
  const app = new Vue({
    el: '#app',
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>