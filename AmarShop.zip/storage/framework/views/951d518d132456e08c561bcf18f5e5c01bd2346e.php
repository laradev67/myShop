<?php $__env->startSection('content'); ?>

  <section class="products">
    <div class="container">
      <div class="columns">
        <div class="column is-3">
          <?php echo $__env->make('partials.product-left-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="column is-9">

          <b-notification type="is-success">
            Total <mark><?php echo e($postproducts->count()); ?></mark> products are available for search <mark> <?php echo e($search); ?>  </mark>
          </b-notification>

          <div class="post-product-lists">
            <?php $__currentLoopData = $postproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <div class="card product-single" onclick="location.href='<?php echo e(route('product.show', $product->slug)); ?>'">
                <div class="card-content">
                  <div class="columns">
                    <div class="column is-5">
                      <figure class="image">
                        <?php $image = DB::table('product_images')->where('product_id', $product->id)->first(); ?>
                        <img src="<?php echo e(asset("images/products/$image->image")); ?>" alt="R1 5 Latest" style="width: 200px;">
                      </figure>
                    </div>
                    <div class="column is-7">
                      <p class="title is-4"><a href="#"><?php echo e($product->title); ?></a></p>
                      <p class="subtitle is-5 is-bold has-text-primary">
                        <?php echo e($product->price); ?> ৳
                      </p>
                      <p class="subtitle is-5">
                        

                        <?php echo e(\Carbon\Carbon::parse($product->created_at)->diffForHumans()); ?>

                      </p>
                      <p class="has-text-right">
                        <a href="<?php echo e(route('product.show', $product->slug)); ?>" class="button is-large is-warning">
                          <i class="fa fa-cart-plus"></i> &nbsp; Buy this Product
                        </a>
                      </p>
                    </div>
                  </div>

                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="pagination" aria-label="pagination">
              <?php echo e($postproducts->links()); ?>

            </div>

            <?php if($postproducts->count() == 0): ?>
              <b-message title="No Products" type="is-primary" has-icon>
                <h2>Sorry !!!</h2>
                <p>
                  There is no product has added yet !! You can add a product here
                </p>
                <p>
                  <a href="<?php echo e(route('product.create')); ?>" class="button is-primary">Add a product Now</a>
                </p>
              </b-message>
            <?php endif; ?>

          </div> <!-- End post-product-lists -->

          <hr />
          <div class="request-product-lists">
            <b-notification type="is-success">
              Total <mark><?php echo e($requestproducts->count()); ?></mark> request products are available for search <mark> <?php echo e($search); ?>  </mark>
            </b-notification>
            <?php $__currentLoopData = $requestproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <div class="card product-single" onclick="location.href='<?php echo e(route('product.request_products.show', $product->slug)); ?>'">
                <div class="card-content">
                  <div class="columns">
                    <div class="column is-5">
                      <figure class="image">
                        <img src="<?php echo e(asset("images/product_requests/$product->image")); ?>" alt="R1 5 Latest" style="width: 200px;">
                      </figure>
                    </div>
                    <div class="column is-7">
                      <p class="title is-4"><a href="#"><?php echo e($product->title); ?></a></p>
                      <p class="subtitle is-5 is-bold has-text-primary">
                        <?php echo e($product->price_range); ?> ৳
                      </p>
                      <p class="subtitle is-5">
                        

                        <?php echo e(\Carbon\Carbon::parse($product->created_at)->diffForHumans()); ?>

                      </p>
                      <p class="has-text-right">
                        <a href="<?php echo e(route('product.request_products.show', $product->slug)); ?>" class="button is-large is-warning">
                          <i class="fa fa-cart-plus"></i> &nbsp; Sell this Product
                        </a>
                      </p>
                    </div>
                  </div>

                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="pagination" aria-label="pagination">
              <?php echo e($requestproducts->links()); ?>

            </div>

            <?php if($requestproducts->count() == 0): ?>
              <b-message title="No Products" type="is-primary" has-icon>
                <h2>Sorry !!!</h2>
                <p>
                  There is no product has added yet !! You can add a product here
                </p>
                <p>
                  <a href="<?php echo e(route('product.create')); ?>" class="button is-primary">Add a product Now</a>
                </p>
              </b-message>
            <?php endif; ?>
          </div>


        </div>
      </div> <!-- End columns -->
    </div> <!-- End container -->

  </section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
  <script>
  const app = new Vue({
    el: '#app',
    data:{
    },
    methods:{

    }
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>