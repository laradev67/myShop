<?php $__env->startSection('stylesheets'); ?> <?php $__env->stopSection(); ?>

  <?php $__env->startSection('content'); ?>

    <section>
      <div class="container">
        <div class="columns">
          <div class="column is-8">
            <p class="has-text-centered section-title is-size-2">
              Post Your Product
            </p>


            <div class="card">
              <form action="<?php echo e(route('product.create')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <section class="p-l-10 p-r-10 p-t-10 p-b-10">

                  <b-field label="Product Title">
                    <b-input name="title" required maxlength="150" value="<?php echo e(old('title')); ?>"></b-input>
                  </b-field>

                  <b-field grouped>
                    <b-field label="Product Price">
                      
                      <b-field>
                        <p class="control">
                          <button class="button">
                            ৳
                          </button>
                        </p>
                        <b-input type="number" name="price" required min=0  value="<?php echo e(old('price')); ?>"></b-input>
                      </b-field>
                    </b-field>


                    <b-field label="Division">
                      <b-select placeholder="Select a division" name="division" required>
                        <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($division->id); ?>"><?php echo e($division->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </b-select>

                    </b-field>

                    <b-field label="District">
                      <b-select placeholder="Select a District" name="district" required>
                        <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($district->id); ?>"><?php echo e($district->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </b-select>
                    </b-field>

                    <b-field label="Protuct Type">
                      <b-select placeholder="Product Type" name="status" is-expanded="true" required>
                        <option value="2">New</option>
                        <option value="1">Old</option>
                      </b-select>
                    </b-field>

                  </b-field> <!-- End b-field grouped -->


                  <b-field grouped>

                    <b-field label="Your Phone">
                      
                      <b-field>
                        <b-input type="text" value="<?php echo e(Auth::user()->phone); ?>" name="phone" required></b-input>
                      </b-field>
                    </b-field>

                    <b-field label="Product Category">
                      <b-select placeholder="Select a Category" name="category" required>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </b-select>
                    </b-field>

                    <b-field label="Product Size">
                      <b-select placeholder="Select a Size" name="size" required>
                        <option value="small">Small</option>
                        <option value="medium">Medium</option>
                        <option value="large">Large</option>
                      </b-select>
                    </b-field>

                    <b-field label="Product Brand">
                      <b-select placeholder="Select a Brand" name="brand">
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </b-select>
                    </b-field>




                  </b-field> <!-- End b-field grouped -->



                  <b-field label="Product Description">
                    <b-input type="textarea" id="description" name="description" required  value="Write your product features or qualities"></b-input>
                  </b-field>


                  <div>
                    <p class="control">
                      <span class="label">Product Featured Image</span>

                      <button @click="addNewImageField" type="button" class="m-l-10  button is-info is-pulled-right"><i class="fa fa-plus"></i></button>
                    </p>

                    <input type="file" class="file-cta m-t-10" name="image1" required>
                    <div id="more-images"></div>


                  </div>


                  <b-collapse :open="false">
                    <button class="button is-info is-small m-t-10 m-b-10 is-pulled-right" slot="trigger" type="button"> <i class="fa fa-plus"></i> For Ecommerce Products (Optional)</button>
                    <div class="is-clearfix"></div>
                    <div class="notification m-t-20">
                      <b-field grouped>
                      </b-field>
                      <b-field label="Shipping Cost">
                        <b-input type="number" name="shipping_cost"><?php echo e(old('shipping_cost')); ?></b-input>
                      </b-field>
                    </b-field> <!-- End b-field grouped -->
                  </div>
                </b-collapse>
                <div class="is-clearfix"></div>

                <b-collapse :open="false">
                  <button class="button is-info is-small m-t-10 m-b-10 is-pulled-right" slot="trigger" type="button"> <i class="fa fa-plus"></i> Add Offer For Fast Buyers between expiry date (Optional)</button>
                  <div class="is-clearfix"></div>
                  <div class="notification">
                    <b-field grouped>
                      <b-field label="Offer Price">
                        <b-field>
                          <b-input type="text" value="<?php echo e(old('offer_price')); ?>" name="offer_price"></b-input>
                        </b-field>
                      </b-field>
                      <b-field label="Select an expiry date">
                        <b-datepicker
                        placeholder="Select Expiry Date"
                        :min-date="minDate"
                        :max-date="maxDate"
                        name="offer_expiry_date"
                        value="<?php echo e(old('offer_expiry_date')); ?>"
                        >
                      </b-datepicker>
                    </b-field>
                    <b-field label="Set Comment for buyer">
                      <b-input type="textarea" name="offer_message"><?php echo e(old('offer_message')); ?></b-input>
                    </b-field>
                  </b-field> <!-- End b-field grouped -->
                </div>

              </b-collapse>
              <div class="is-clearfix"></div>


              <div class="field is-grouped m-t-20">
                <div class="control">
                  <button type="submit" class="button is-primary">Publish Product</button>
                </div>
                <div class="control">
                  <a href="<?php echo e(route('index')); ?>" class="button is-danger">Cancel</a>
                </div>
              </div>

            </section>
          </form>
        </div> <!-- End form card div -->



      </div>
      <div class="column is-4">
        <p class="has-text-centered section-title is-size-3">
          Featured Product
        </p>

        <?php $__empty_1 = true; $__currentLoopData = $featureds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $featured): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <div class="card" onclick="document.location='<?php echo e(route('product.show', $featured->product->slug)); ?>'" style="cursor: pointer">
            <div class="card-image">
              <td>
                <?php $image = DB::table('product_images')->where('product_id', $featured->product->id)->first(); ?>
                <img src="<?php echo e(asset("images/products/$image->image")); ?>" alt="R1 5 Latest">
              </td>
            </div>
            <div class="card-content">
              <div class="media">
                <div class="media-content">
                  <p class="title is-4"><?php echo e($featured->product->title); ?></p>
                  <p class="subtitle is-6"><?php echo e($featured->product->price); ?>৳</p>
                </div>
              </div>

              <div class="content">
                Posted <?php echo e(\Carbon\Carbon::parse($featured->product->created_at)->diffForHumans()); ?>

              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          
        <?php endif; ?>


      </div>
    </div>
  </div>
</section>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

  <script src="<?php echo e(asset('js/tinymce/tinymce.min.js')); ?>"></script>
  <script>
  tinymce.init({
    selector:'#description' ,
    // plugins:'link code image imagetools',
    plugins:['autolink lists link image preview hr anchor pagebreak searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime table'],

    toolbar1: ' styleselect | bold italic underline hr link image | bullist numlist | table insert searchreplace undo redo | fontselect  preview code ',
    image_advtab: true,
    menubar:false
  });</script>

  <script>
  var today = new Date();

  const app = new Vue({
    el: '#app',
    data:{
      open: false,
      image: 1,
      date: new Date(),
      minDate: new Date(this.today.getFullYear(), this.today.getMonth(), this.today.getDate()),
      maxDate: new Date(this.today.getFullYear(), this.today.getMonth(), this.today.getDate() + 30)
    },
    methods:{

      addNewImageField(){
        //Add another input field as image1/image2/image3
        this.image++
        if(this.image <= 3){
          //Add one input field
          var more_images = document.getElementById('more-images')
          var create_img = document.createElement("div");
          // <input type="file" class="file-cta p-t-5"  name="image' + this.image + '"><br />
          create_img.innerHTML =  '<input type="file" class="file-cta m-t-5 "  name="image' + this.image + '"><br />'
          more_images.appendChild(create_img)

          // var objTo = document.getElementById('room_fileds')
          // var divtest = document.createElement("div");
          // divtest.innerHTML = '<div class="label">Room ' + room +':</div><div class="content"><span>Width: <input type="text" style="width:48px;" name="width[]" value="" /><small>(ft)</small> X</span><span>Length: <input type="text" style="width:48px;" namae="length[]" value="" /><small>(ft)</small></span></div>';

          // objTo.appendChild(divtest)

        }
      },


    }


  });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>