<?php $__env->startSection('stylesheets'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section class="products">
  <div class="container">
    <div class="columns">
      <div class="column is-3">
        <?php echo $__env->make('partials.product-left-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
      <div class="column is-9">

        <div class="card">
          <div class="card-content">
            <div class="columns">

              <div class="column is-5">
                  <figure class="image product-image-gallery">
                    <?php if(($product->image == NULL) || ($product->image == "")): ?>
                      <img src="<?php echo e(asset("images/product_requests/default.png")); ?>" alt="" >
                    <?php else: ?>
                      <img src="<?php echo e(asset("images/product_requests/$product->image")); ?>" alt="" >
                    <?php endif; ?>
                </figure>
            </div>


            <div class="column is-7">
              
                <p class="title is-4 is-pulled-left"><a href="#"><?php echo e($product->title); ?></a></p>
                
                <p class="is-pulled-right">
                  <button class="button is-primary" @click="callPublisher(<?php echo e($product->phone); ?>)"><i class="fa fa-phone"></i></button>
                </p>
                <p class="is-clearfix"></p>
              

              <p class="subtitle is-5 is-bold has-text-primary">
                <?php echo e($product->price_range); ?>৳
              </p>
              <p class="subtitle is-6">
                <?php echo $product->description; ?>

              </p>
              <hr />

              <div class="subtitle is-6">
                <p><strong>Category : </strong> <?php echo e($product->category->name); ?></p>
                <p><strong>Brand : </strong> <?php echo e(($product->brand != NULL) ? $product->brand->name : 'Any Brand'); ?></p>
                <p><strong>Size : </strong> <?php echo e($product->size); ?></p>
                <hr />

                <p><strong>Published By : </strong> <?php echo e($product->user->name); ?></p>
              </div>

              <p class="has-text-right">
                
                <button class="button is-large is-warning"
                @click="isComponentModalActive = true">
                Buy This Product
              </button>
            </p>

            <b-modal :active.sync="isComponentModalActive" has-modal-card>
              <modal-form><?php echo $__env->make('components.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></modal-form>
            </b-modal>


          </div>
        </div>

      </div>
    </div>

  </div>
</div> <!-- End columns -->
</div> <!-- End container -->



</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>

  const app = new Vue({
    el: '#app',
    data:{
      isComponentModalActive: false,
    },

    methods:{

      callPublisher(phone){
        this.$dialog.alert({
          title: 'Call Publisher',
          message: 'Call the Publisher Directly To Buy The Product. <br /> <strong>Phone No: </strong> '+phone +'<br /> <a class="button is-primary" href="tel:'+phone+'"><i class="fa fa-phone"></a></a>',
          type: 'is-primary',
          hasIcon: true,
          icon: 'phone',
          confirmText: 'Cancel',
          iconPack: 'fa'
        })
      }
    },

  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>