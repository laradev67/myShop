<?php $__env->startSection('content'); ?>

  <!-- <section class="top">
  <div class="container">
  <div class="card">
  <header class="card-header">
  <p class="card-header-title">
  Welcome <?php echo e(Auth::check() ? Auth::user()->name : 'Guest'); ?>

</p>
</header>
<div class="card-content">
<div class="content">
<p>
Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiis molestias, ab voluptas hic ut, est doloremque. Nostrum quidem tenetur illum sunt saepe! Pariatur dolorum nam quia ullam aliquam sapiente enim.
</p>
</div>
</div>
</div>
</div>
</section> -->


<section class="hero">
  <div class="hero-body">
    <div class="container">
      

    <div class="columns">
      <div class="column">
        <div class="card">
          <a href="<?php echo e(route('product.create')); ?>" class="link-bigger link-bigger-transition top-link1">
            Have you a Product ? <br />Wanna sell ?
            <img src="<?php echo e(asset('images/main/sell.jpg')); ?>" alt="">
          </a>
        </div>
      </div>
      <div class="column">
        <div class="card">
          <a href="<?php echo e(route('product.request')); ?>" class="link-bigger link-bigger-transition top-link2">Need a product ? <br />Wanna Buy ?
            <img src="<?php echo e(asset('images/main/buy3.png')); ?>" alt="">
          </a>
        </div>
      </div>
      <div class="column">
        <div class="card">
          <a href="<?php echo e(route('company.welcome')); ?>" class="link-bigger link-bigger-transition top-link3">
            Have you a company ? <br />Wanna sell ?
            <img src="<?php echo e(asset('images/main/company.jpg')); ?>" alt="">
          </a>
        </div>
      </div>
    </div>
  </div>
</div>
</section>



<section class="hero m-b-5 p-b-30">
  <div class="container">
    <p class="section-title m-b-30">
      Get any product from your favorite division
    </p>
    <div class="columns is-multiline is-mobile is-centered">
      <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="column is-info">
        <div class="division has-text-centered link-bigger-transition">
          <a href="<?php echo route('product.division.index', $division->slug); ?>" class="link-full-display link-div-big is-in has-text-danger">
            <img src="<?php echo e(asset("images/divisions/$division->image")); ?>" alt="">
            <br />
            <span><?php echo e($division->name); ?></span>
          </a>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section>


<section class="hero m-b-5 p-b-30">
  <div class="container">
    <p class="section-title m-b-30">Get products from the categories</p>
    <div class="columns is-multiline is-mobile is-centered">
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($category->products()->count() > 0 ): ?>
      <div class="column is-info is-3">
        <div class="category has-text-centered link-bigger-transition">
          <a href="<?php echo route('product.category.index', $category->slug); ?>" class="link-full-display link-div-big is-in has-text-danger">
            <img src="<?php echo e(asset("images/categories/$category->image")); ?>" alt="">
            <br />
            <span><?php echo e($category->name); ?></span>
          </a>
        </div>
      </div>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <a href="<?php echo route('categories'); ?>" class="button is-primary is-large is-pulled-right">More Categories...</a>
  </div>
</section>


<section class="hero m-b-5 p-b-30">
  <div class="container">
    <p class="section-title m-b-30">Get products from the brands</p>
    <div class="columns is-multiline is-mobile is-centered">
      <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="column is-info is-3">
        <div class="category has-text-centered link-bigger-transition">
          <a href="<?php echo route('product.brand.index', $brand->slug); ?>" class="link-full-display link-div-big is-in has-text-danger">
            <img src="<?php echo e(asset("images/brands/$brand->image")); ?>" alt="">
            <br />
            <?php echo e($brand->name); ?>

          </a>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <a href="<?php echo route('brands'); ?>" class="button is-primary is-large is-pulled-right">More Brands...</a>
  </div>
</section>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
  const app = new Vue({
    el: '#app',
    data:{
    },
    methods:{

      confirmCustomDelete() {
        this.$dialog.confirm({
          title: 'Deleting account',
          message: 'Are you sure you want to <b>delete</b> your account? This action cannot be undone.',
          confirmText: 'Delete Account',
          type: 'is-danger',
          hasIcon: true,
          onConfirm: () => {
            return true
          }
        })
      },


      //Test a vue js function
      give_permission(permission) {
        if(permission == 2){
          alert('Ok');
        }else {
          alert('Nope');
        }
      }


    }


  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>