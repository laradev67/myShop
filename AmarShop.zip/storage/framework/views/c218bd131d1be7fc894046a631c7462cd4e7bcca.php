<?php $__env->startSection('title'); ?>
Notification | Amar Shop
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<section class="products">
  <div class="container">
    <div class="columns">
      <div class="column is-3">
        <?php echo $__env->make('partials.product-left-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
      <div class="column is-9">
        <b-tabs>
          <b-tab-item label="UnSeen" class="is-primary">
            <table class="table is-hoverable is-striped is-fullwidth is-bordered">
              <thead>
                <tr>
                  <th>Sl</th>
                  <th>Product</th>
                  <th>Expiry Time</th>
                  <th>Action</th>
                </tr>
              </thead>
              <?php $i = 1; ?>
              <?php $__empty_1 = true; $__currentLoopData = $unseen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tbody>
                <tr>
                  <td><?php echo e($i); ?></td>
                  <td><?php echo e(($notification->product_id != null) ? $notification->product->title : ''); ?></td>
                  <td>
                    <?php echo e(\Carbon\Carbon::parse($notification->product->offer_expiry_date)->diffForHumans()); ?>

                  </td>
                  <td>
                    <a href="<?php echo e(route('notification.show', $notification->id)); ?>" class="button is-info"><i class="fa fa-eye"></i></a>

                    <form class="form-inline" action="<?php echo route('notification.delete', $notification->id); ?>" method="post"  onsubmit="return confirm('Do you wan to delete the notification ? ')">
                      <?php echo e(csrf_field()); ?>

                      <button type="submit" class="button is-danger" onsubmit="return confirm('Do you wan to delete the notification ? ')"><i class="fa fa-trash"></i></button>

                    </form>
                  </td>
                </tr>
              </tbody>
              <?php $i++; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td>No notifications</td>
              </tr>
              <?php endif; ?>

            </table>
          </b-tab-item>

          <b-tab-item label="Seen">
            <table class="table is-hoverable is-striped is-fullwidth is-bordered">
              <thead>
                <tr>
                  <th>Sl</th>
                  <th>Product</th>
                  <th>Expiry Time</th>
                  <th>Action</th>
                </tr>
              </thead>
              <?php $i = 1; ?>
              <?php $__empty_1 = true; $__currentLoopData = $seen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tbody>
                <tr>
                  <td><?php echo e($i); ?></td>
                  <td><?php echo e(($notification->product_id != null) ? $notification->product->title : ''); ?></td>
                  <td>
                    <?php echo e(\Carbon\Carbon::parse($notification->product->offer_expiry_date)->diffForHumans()); ?>

                  </td>
                  <td>
                    <a href="<?php echo e(route('notification.show', $notification->id)); ?>" class="button is-info"><i class="fa fa-eye"></i></a>

                    <form class="form-inline" action="<?php echo route('notification.delete', $notification->id); ?>" method="post"  onsubmit="return confirm('Do you wan to delete the notification ? ')">
                      <?php echo e(csrf_field()); ?>

                      <button type="submit" class="button is-danger" onsubmit="return confirm('Do you wan to delete the notification ? ')"><i class="fa fa-trash"></i></button>

                    </form>
                  </td>
                </tr>
              </tbody>
              <?php $i++; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td>No notifications</td>
              </tr>
              <?php endif; ?>

            </table>
          </b-tab-item>
        </b-tabs>


        
      </div>
    </div> <!-- End columns -->
  </div> <!-- End container -->



</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
 const app = new Vue({
  el: '#app',
  data:{
  },
  methods:{

  }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>