<nav class="navbar m-b-5 is-primary" role="navigation" aria-label="main navigation">
  <div class="container">
    <div class="navbar-brand">
      <a class="navbar-item" href="<?php echo e(url('/')); ?>">
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="<?php echo e(config('name')); ?>" width="112" height="50">
      </a>


      <div class="navbar-burger burger" data-target="navMenu">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
    <div class="navbar-menu"  id="navMenu">
      <div class="navbar-start">
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="navbar-item"> Admin Panel </a>
        <a href="<?php echo e(route('index')); ?>" class="button is-info is-small m-t-15" target="_blank"> <i class="fa fa-eye"></i> View Site </a>
      </div>
      <div class="navbar-end">

        <div class="navbar-item">
          <div class="field has-addons m-t-5">
            <div class="control">
              <input class="input" type="text" placeholder="Search Your Prodcuts">
            </div>
            <div class="control">
              <a class="button is-info">
                <i class="fa fa-search"></i>
              </a>
            </div>
          </div>
        </div>

        <?php if(Auth::check()): ?>
        <div class="navbar-item has-dropdown is-hoverable">
          <a class="navbar-link">
           <?php echo e(Auth::user()->name); ?>

         </a>

         <div class="navbar-dropdown">
          <a href="<?php echo e(route('home')); ?>" class="navbar-item"> Setup Admin Profile </a>
          <a href="<?php echo e(route('home')); ?>" class="navbar-item"> Change Admin Password </a>
          <a href="<?php echo e(route('home')); ?>" class="navbar-item"> Logout </a>
        </div>
      </div>
      <?php endif; ?> 



      </div>
    </div> <!--End Navbar Menu-->


  </div>
</nav>

