<?php $__env->startSection('content'); ?>

<div id="categoryIndex">
  <nav class="breadcrumb" aria-label="breadcrumbs">
    <ul class="is-left">
      <li><a href="<?php echo e(route('admin.dashboard')); ?>">Admin</a></li>
      <li class="is-active"><a href="#" aria-current="page">Manage Categories</a></li>
    </ul>
    <ul class="is-right">
      <li  class="is-right"><a href="<?php echo e(route('admin.category.create')); ?>" class="button button is-primary">Create New Category</a></li>
    </ul>
  </nav>


  <div class="columns">
    <div class="column is-12">
      <div class="card events-card">
        <header class="card-header">
          <p class="card-header-title">
            Manage Categories
          </p>
          <a href="#" class="card-header-icon" aria-label="more options">
            <span class="icon">
              <i class="fa fa-angle-down" aria-hidden="true"></i>
            </span>
          </a>
        </header>
        <div class="card-table">
          <div class="content">
            <table class="table is-fullwidth is-striped">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Image</th>
                  <th>Parent Category</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>

                <?php $i=1; ?>
                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                  <td><?php echo e($i); ?></td>
                  <td><?php echo e($category->name); ?></td>
                  <td>
                    <a href="<?php echo e(asset("images/categories/$category->image")); ?>" target="blank">
                      <img src='<?php echo e(asset("images/categories/$category->image")); ?>' alt="" style="width: 50px">
                    </a>

                  </td>
                  <td>
                    <?php
                    if($category->parent_id != NULL || $category->parent_id != 0){
                      $parent_category = App\Category::where('id', $category->parent_id)->first();
                      if($parent_category){
                        $parent_category = $parent_category->name;
                      }else{
                       $parent_category = "Parent Removed";
                     }
                   }else{
                    $parent_category = "Own";
                  }
                  ?>
                  <?php echo e($parent_category); ?>

                </td>
                <td>
                  <a href="<?php echo e(route('admin.category.edit', $category->id)); ?>" class="button is-success"><i class="fa fa-pencil"></i></a>


                  <form @submit.prevent="confirmCustomDelete(<?php echo e($category->id); ?>)" action="<?php echo e(route('admin.category.delete', $category->id)); ?>" class="form-inline" method="POST" >
                    <?php echo e(csrf_field()); ?>

                    <button type="submit" class="button is-danger"><i class="fa fa-trash"></i></button>
                  </form>






                  </td>
                  <?php $i++; ?>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                  <td colspan="4">No Data Here</td>
                </tr>
                <?php endif; ?>

              </tbody>
            </table>
          </div>
        </div>
        <footer class="card-footer">
          <div>
            <?php echo e($categories->links()); ?>

          </div>
          <a href="#" class="card-footer-item">View All</a>
        </footer>
      </div>     
    </div>
  </div>
</div> <!-- End Category Index -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
 const app = new Vue({
  el: '#app',
  methods:{



    confirmCustomDelete(id) {
      this.$dialog.confirm({
        title: 'Deleting Category '+id,
        message: 'Are you sure you want to <b>delete</b> the category? This action cannot be undone.',
        confirmText: 'Delete Category',
        type: 'is-danger',
        hasIcon: true,
        onConfirm: () => {
          //Delete the category and toast a message
          axios.delete('/admin/category/'+id)
          .then(response=>{
            //Refresh
            document.location.reload(true)
            //this.fetchCategories()
            //
            
            app.$toast.open({
              duration: 2000,
              message: 'Category Deleted Successfully',
              type: 'is-success'
            })

          })
        }
      })
    },

    // fetchCategories(){
    //   axios.get('/admin/category/'+id)
    // }




  }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>