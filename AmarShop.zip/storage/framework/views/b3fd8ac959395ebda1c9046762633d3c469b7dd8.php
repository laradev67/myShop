<?php $__env->startSection('content'); ?>

<section class="hero">
  <div class="hero-body">
    <div class="container">
      <h2 class="title">Advance Search</h2>
      <search></search>
  </div>
</div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
  const app = new Vue({
    el: '#app',
    data:{

    },
    methods:{

    }
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>