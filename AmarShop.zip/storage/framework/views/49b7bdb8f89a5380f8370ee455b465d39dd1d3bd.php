<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="columns">
        <div class="column is-8">

            <div class="card">
              <header class="card-header">
                <p class="card-header-title">Create A New Account</p>
            </header>
            <div class="card-content">

                <form action="<?php echo e(route('register')); ?>" method="POST" class="p-b-20" enctype="multipart/form-data">

                    <?php echo e(csrf_field()); ?>



                    <div class="field is-horizontal">
                      <div class="field-label is-normal">
                        <label class="label">Choose Account Type</label>
                    </div>

                    <div class="field-body">
                        <b-field>
                            <div class="select">
                                <select class="is-fullwidth" name="is_company" required>
                                    <option value="0" selected>As a user</option>
                                    <option value="1">As a Company</option>
                                </select>
                            </div>
                        </b-field>
                    </div> <!--End Field Body -->
                </div> <!--End Field Horizontal-->


                <div class="field is-horizontal">
                  <div class="field-label is-normal">
                    <label class="label">Name</label>
                </div>

                <div class="field-body">
                    <b-field>
                        <b-input placeholder="Name" name="name" icon="user" required maxlength=30></b-input>
                    </b-field>
                </div> <!--End Field Body -->
            </div> <!--End Field Horizontal-->




            <div class="field is-horizontal">

              <div class="field-label is-normal">
                <label class="label">Email</label>
            </div>
            <div class="field-body">
                <b-field>
                    <b-input placeholder="Primary Email" type="email" name="email" icon="envelope" is-expanded="true" required ></b-input>
                </b-field>
            </div> <!--End Field Body -->
        </div> <!--End Field Horizontal-->


        <div class="field is-horizontal">
          <div class="field-label is-normal">
            <label class="label">Phone No</label>
        </div>

        <div class="field-body">
            <div class="field-body">
                <b-field>
                    <b-input placeholder="01951233084" type="text" name="phone" icon="phone" is-expanded="true" required ></b-input>
                </b-field>
            </div> <!--End Field Body -->
        </div> <!--End Field Body -->
    </div> <!--End Field Horizontal-->


    <div class="field is-horizontal">
      <div class="field-label is-normal">
        <label class="label">Division / District</label>
    </div>

    <div class="field-body">
        <b-field>
            <b-select placeholder="Select a Division" class="is-fullwidth" name="division_id" required>
                <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($division->id); ?>"><?php echo e($division->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </b-select>
        </b-field>
        <b-field>
            <b-select placeholder="Select a District" class="is-fullwidth" name="district_id" required>
                <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($district->id); ?>"><?php echo e($district->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </b-select>
        </b-field>

    </div> <!--End Field Body -->
</div> <!--End Field Horizontal-->


<div class="field is-horizontal">
  <div class="field-label is-normal">
    <label class="label">Street</label>
</div>

<div class="field-body">
    <b-field>
        <b-input placeholder="Street Address" type="text" name="street_address" icon="address-book" maxLength=100></b-input>
    </b-field>
</div> <!--End Field Body -->
</div> <!--End Field Horizontal-->

<div class="field is-horizontal">
  <div class="field-label is-normal">
    <label class="label">Password</label>
</div>

<div class="field-body">
    <b-field>
        <b-input placeholder="Password" type="password" name="password" icon="lock" required password-reveal></b-input>
    </b-field>
    <b-field>
        <b-input placeholder="Confirm Password" type="password" name="password_confirmation" icon="lock" required password-reveal></b-input>
    </b-field>
</div> <!--End Field Body -->
</div> <!--End Field Horizontal-->



<div class="field-body is-centered">
    <p class="control is-centered">
        <button class="button is-primary" type="submit">Register</button>
    </p>
</div> <!--End Field Body -->
</form> <!--End User Registration Form -->



</div> <!-- Card content -->

</div> <!--End card -->


</div> <!-- End col-is-8 -->





<div class="column is-4">
    <div class="card">
      <header class="card-header">
        <p class="card-header-title">Login</p>
    </header>
    <div class="card-content">
        <form action="<?php echo e(route('login')); ?>" method="POST" class="">
            <?php echo e(csrf_field()); ?>

            <div class="field">
                <b-field>
                    <b-input placeholder="Primary Email" type="email" name="email" icon="envelope" required></b-input>
                </b-field>
            </div>
            <div class="field">
                <b-field>
                    <b-input type="password" name="password" icon="lock"  required password-reveal> </b-input>
                </b-field>
            </div>

            <div class="field">
                <b-checkbox name="remember" value="<?php echo e(old('remember')); ?>">Remember Me</b-checkbox>
            </div>


            <div class="field-body is-centered">
                <p class="control is-centered">
                    <button class="button is-primary" type="submit">Login</button>
                </p>
            </div> <!--End Field Body -->
        </form>
    </div>

</div> <!--End card -->
</div>



</div>

</div>










<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
   const app = new Vue({
      el: '#app',
      data:{

      },
      methods:{

      }


  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>