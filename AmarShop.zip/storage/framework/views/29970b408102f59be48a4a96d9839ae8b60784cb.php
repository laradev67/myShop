<?php $__env->startSection('content'); ?>

  <section class="products">
    <div class="container">
      <div class="columns">
        <div class="column is-3">
          <?php echo $__env->make('partials.product-left-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="column is-9">
          
          <?php if($wishlists != null): ?>
            <b-notification type="is-success">
              Total <mark><?php echo e($wishlists->count()); ?></mark> products have added to your wishlist
            </b-notification>
          <?php endif; ?>
          <?php $__currentLoopData = $wishlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wishlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="card product-single" onclick="location.href='<?php echo e(route('product.show', $wishlist->product->slug)); ?>'">
              <div class="card-content">
                <div class="columns">
                  <div class="column is-5">
                    <figure class="image">
                      <?php $image = DB::table('product_images')->where('product_id', $wishlist->product->id)->first(); ?>
                      <img src="<?php echo e(asset("images/products/$image->image")); ?>" alt="R1 5 Latest" style="width: 200px;">
                    </figure>
                  </div>
                  <div class="column is-7">
                    <p class="title is-4"><a href="#"><?php echo e($wishlist->product->title); ?></a></p>
                    <p class="subtitle is-5 is-bold has-text-primary">
                      <?php echo e($wishlist->product->price); ?> ৳
                    </p>
                    <p class="subtitle is-5">
                      

                      <?php echo e(\Carbon\Carbon::parse($wishlist->product->created_at)->diffForHumans()); ?>

                    </p>
                    <p class="has-text-right">
                      <a href="<?php echo e(route('product.show', $wishlist->product->slug)); ?>" class="button is-large is-warning">
                        <i class="fa fa-cart-plus"></i> &nbsp; Buy this Product
                      </a>
                    </p>
                  </div>
                </div>

              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <div class="pagination" aria-label="pagination">
            <?php echo e($wishlists->links()); ?>

          </div>

          <?php if($wishlists->count() == 0): ?>
            <b-message title="No Products" type="is-primary" has-icon>
              <h2>Sorry !!!</h2>
              <p>
                There is no product has added yet !! You can add a product here
              </p>
              <p>
                <a href="<?php echo e(route('product.create')); ?>" class="button is-primary">Add a product Now</a>
              </p>
            </b-message>
          <?php endif; ?>

        </div>
      </div> <!-- End columns -->
    </div> <!-- End container -->
  </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script>
  const app = new Vue({
    el: '#app',
    data:{
    },
    methods:{
    }
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>