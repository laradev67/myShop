<?php $__env->startSection('content'); ?>
<div class="columns">
    <div class="column is-one-third is-offset-one-third">
        <div class="card">

            <div class="card-content">
                <h1 class="title has-text-centered">Join Our Community</h1>
                <form action="<?php echo e(route('register')); ?>" method="POST" role="form">
                    <?php echo e(csrf_field()); ?>


                    <div class="field">
                        <label class="label" for="name">Name</label>
                        <div class="control">
                           <input class="input <?php echo e($errors->has('name') ? 'is-danger' : ''); ?>" type="text" placeholder="test@example.com" name="name" id="name" value="<?php echo e(old('name')); ?>" required>
                       </div>
                       <?php if($errors->has('name')): ?>
                       <p class="help is-danger"><?php echo e($errors->first('name')); ?></p>
                       <?php endif; ?>
                   </div>

                   <div class="field">
                    <label class="label" for="email">Email Address</label>
                    <div class="control">
                       <input class="input <?php echo e($errors->has('email') ? 'is-danger' : ''); ?>" type="text" placeholder="test@example.com" name="email" id="email" value="<?php echo e(old('email')); ?>" required>
                   </div>
                   <?php if($errors->has('email')): ?>
                   <p class="help is-danger"><?php echo e($errors->first('email')); ?></p>
                   <?php endif; ?>
               </div>

               <div class="columns">
                <div class="column">
                    <div class="field">
                        <label class="label" for="password">Password</label>
                        <div class="control">
                           <input class="input <?php echo e($errors->has('password') ? 'is-danger' : ''); ?>" type="password" placeholder="Password" name="password" id="password" required>
                       </div>
                       <?php if($errors->has('password')): ?>
                       <p class="help is-danger"><?php echo e($errors->first('password')); ?></p>
                       <?php endif; ?>
                   </div>
               </div>
               <div class="column">
                <div class="field">
                    <label class="label" for="password_confirmation">Confirm Password</label>
                    <div class="control">
                       <input class="input" type="password_confirmation" placeholder="Password" name="password_confirmation" id="password_confirmation" required>
                   </div>
               </div>
           </div>
       </div>

       <button class="button is-primary is-outlined is-fullwidth m-t-30">Join Now</button>
   </form>

</div> <!--End .card-content-->
</div> <!-- End div.card -->

<h5 class="has-text-centered m-t-20"><a href="<?php echo e(route('login')); ?>" class="has-text-primary ">Already have an account ? Back to Login</a></h5>

</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>