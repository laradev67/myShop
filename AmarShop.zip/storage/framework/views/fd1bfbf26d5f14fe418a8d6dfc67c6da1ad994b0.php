<aside class="menu">
  <p class="menu-label">
    General
  </p>
  <ul class="menu-list">
    <li><a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo e((Route::current()->getName() == "admin.dashboard") ? 'is-active' : 'null'); ?>">Dashboard</a></li>

  </ul>
  <p class="menu-label">
    Administration
  </p>
  <ul class="menu-list">
    <li><a href="<?php echo e(route('admin.user')); ?>"class="<?php echo e((Route::current()->getName() == "admin.user") ? 'is-active' : 'null'); ?>">Manage Users</a></li>

    <li>
      <b-collapse :open="true">
        <a slot="trigger">Manage Products</a>
        <ul>
          <li><a href="<?php echo e(route('admin.product.index')); ?>" class="<?php echo e((Route::current()->getName() == "admin.product.index") ? 'is-active' : 'null'); ?>">Manage Products</a></li>
          <li><a>Create Products</a></li>
          <li><a href="<?php echo e(route('admin.product.featured')); ?>" class="<?php echo e((Route::current()->getName() == "admin.product.featured") ? 'is-active' : 'null'); ?>">Featured Products</a></li>
          <li><a href="<?php echo e(route('admin.product.request_products')); ?>">Product Requests</a></li>
        </ul>
      </b-collapse>
    </li>

    <li>
      <b-collapse :open="true">
        <a slot="trigger">Manage Orders</a>
        <ul>
          <li>
            <a href="<?php echo e(route('admin.order')); ?>" class="<?php echo e((Route::current()->getName() == "admin.order") ? 'is-active' : 'null'); ?>">Incomplete Orders</a>
          </li>
           <li><a href="<?php echo e(route('admin.order.complete')); ?>" class="<?php echo e((Route::current()->getName() == "admin.order.complete") ? 'is-active' : 'null'); ?>">Complete Orders</a></li>
          
        </ul>
      </b-collapse>
    </li>

    <li>
      <b-collapse :open="<?php echo e(((Request::is('admin/category')) || (Request::is('admin/category/*'))) ? 'true' : 'false'); ?>">
        <a slot="trigger">Manage Category</a>
        <ul>
          <li><a href="<?php echo e(route('admin.category.index')); ?>" class="<?php echo e((Route::current()->getName() == "admin.category.index") ? 'is-active' : 'null'); ?>">Manage Category</a></li>
          <li><a href="<?php echo e(route('admin.category.create')); ?>" class="<?php echo e((Route::current()->getName() == "admin.category.create") ? 'is-active' : 'null'); ?>">Create Category</a></li>
        </ul>
      </b-collapse>
    </li>

    <li>
      <b-collapse :open="<?php echo e(((Request::is('admin/brand')) || (Request::is('admin/brand/*'))) ? 'true' : 'false'); ?>">
        <a slot="trigger">Manage brand</a>
        <ul>
          <li><a href="<?php echo e(route('admin.brand.index')); ?>" class="<?php echo e((Route::current()->getName() == "admin.brand.index") ? 'is-active' : 'null'); ?>">Manage brand</a></li>
          <li><a href="<?php echo e(route('admin.brand.create')); ?>" class="<?php echo e((Route::current()->getName() == "admin.brand.create") ? 'is-active' : 'null'); ?>">Create brand</a></li>
        </ul>
      </b-collapse>
    </li>


    <li><a>Settings</a></li>
  </ul>


  <p class="menu-label">
    Others
  </p>
  <ul class="menu-list">

    <li>
      <a href="<?php echo e(route('admin.district.index')); ?>"
      class="<?php echo e(((Route::current()->getName() == "admin.district.index") || (Route::current()->getName() == "admin.district.edit")) ? 'is-active' : 'null'); ?>">Manage Districts</a>
    </li>
    <li>
      <a href="<?php echo e(route('admin.division.index')); ?>"
      class="<?php echo e(((Route::current()->getName() == "admin.division.index") || (Route::current()->getName() == "admin.division.edit")) ? 'is-active' : 'null'); ?>">Manage Division</a>
    </li>

    <li><a>Transfers</a></li>
    <li><a>Balance</a></li>
  </ul>
</aside>


