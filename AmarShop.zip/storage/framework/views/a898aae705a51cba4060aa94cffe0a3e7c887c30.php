<?php $__env->startSection('content'); ?>

<div id="categoryIndex">
  <nav class="breadcrumb" aria-label="breadcrumbs">
    <ul class="is-left">
      <li><a href="<?php echo e(route('admin.dashboard')); ?>">Admin</a></li>
      <li><a href="<?php echo e(route('admin.order')); ?>">Order</a></li>
      <li class="is-active"><a href="#" aria-current="page"><?php echo e($order->shipping->name); ?>'s Order</a></li>
    </ul>
  </nav>


  <div class="columns">
    <div class="column is-12">
      <div class="card events-card">
        <header class="card-header">
          <p class="card-header-title">
            Order Informations
          </p>
        </header>

        <div class="card-content">
          
          
          <div class="notification m-t-30">          
            <h3 class="has-text-weight-bold has-text-success">Product Item and Price Informations</h3>
            <table class="table is-fullwidth">
              <thead>
                <tr>
                  <th>Item No</th>
                  <th>Product Name</th>
                  <th>Price * Quantity</th>
                  <th>Company</th>
                  <th>Shipping Cost</th>
                </tr>
              </thead>
              <tbody>
                <?php $i = 1; ?>
                <?php $__currentLoopData = $order->order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($i); ?></td>
                  <td><?php echo e($item->product->title); ?></td>
                  <td>
                    <p><?php echo e($item->product->price); ?> * <?php echo e($item->item_quantity); ?> </p>
                    <p class="has-text-weight-bold has-text-info">= <?php echo e($item->product->price * $item->item_quantity); ?> </p>
                  </td>
                  <td>
                   <a href="<?php echo e(route('user.show', $item->product->user->username)); ?>" title=""> <?php echo e($item->product->user->name); ?></a>
                 </td><td>
                  <?php echo e($item->product->shipping_cost); ?>

                </td>
              </tr>
              <?php $i++; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td colspan="4" rowspan="" headers="">


                </td>
              </tr>

            </tbody>
          </table>
        </div>

        <div class="notification m-t-30">          
          <h3 class="has-text-weight-bold has-text-success"> Transaction Related Informations</h3>
          <table class="table is-fullwidth">
            <thead>
              <tr>

                <th>Payment Method</th>
                <th>Payment Transaction</th>
                <th>Payment Informations</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>

             
             <tr>
              <td><?php echo e($order->payment->payment_method->name); ?></td>
              <td><?php echo e($order->payment->payment_transaction); ?></td>
              <td><?php echo e($order->payment->payment_informations); ?></td>
              <td>

                <form action="<?php echo e(route('admin.order.is_paid', $order->id)); ?>" method="post">
                  <?php echo e(csrf_field()); ?>

                  <?php if($order->payment->is_paid): ?>
                  <button type="submit" class="button is-danger"> <i class="fa fa-check"></i> Cancel Payment Transaction</button>
                  <?php else: ?>
                  <button type="submit" class="button is-success"> <i class="fa fa-check"></i> Confirm Payment Transaction</button>
                  <?php endif; ?>
                </form>

              </td>
            </tr>
            
          </tbody>
        </table>
      </div>

      <div class="notification m-t-30">          
        <h3 class="has-text-weight-bold has-text-success">Send Money To Company/Customers</h3>
        <div class="notification">

         <?php $i = 1; ?>
         <?php $__currentLoopData = $order->order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         
         <p><?php echo e($item->product->price); ?> * <?php echo e($item->item_quantity); ?> </p>
         <p class="has-text-weight-bold has-text-info">= <?php echo e($item->product->price * $item->item_quantity); ?> </p>
         

         <?php echo e($item->product->user->name); ?>

         <?php echo e($item->product->shipping_cost); ?>

         
         <?php $i++; ?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       </div>
       <?php if($order->is_completed_by_admin): ?>
       <form action="<?php echo e(route('admin.order.deliver', $order->id)); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <button type="submit" class="button is-danger"> <i class="fa fa-check"></i>Order has deliverd !!! Cancel Delivery Now ?</button>
      </form>
      <?php else: ?>
      <form action="<?php echo e(route('admin.order.deliver', $order->id)); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <button type="submit" class="button is-info"> <i class="fa fa-check"></i> Distribute Money,Orders To Companies</button>
      </form>
      <?php endif; ?>
    </div>




  </div>

</div>
</div>
</div>
</div> <!-- End Category Index -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
 const app = new Vue({
  el: '#app',
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>