<?php $__env->startSection('stylesheets'); ?> <?php $__env->stopSection(); ?>
  <?php $__env->startSection('content'); ?>


    <section>
      <div class="container">
        <div class="columns">
          <div class="column is-8">
            <p class="has-text-centered section-title is-size-2">
              Post Your Product Request
            </p>


            <div class="card">
              <form action="<?php echo e(route('product.request')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <section class="p-l-10 p-r-10 p-t-10 p-b-10">

                  <b-field label="Product Title">
                    <b-input name="title" required maxlength="150" value="<?php echo e(old('title')); ?>"></b-input>
                  </b-field>

                  <b-field grouped>
                    <b-field label="Price range">
                      
                      <b-field>
                        <p class="control">
                          <button class="button">
                            ৳
                          </button>
                        </p>
                        <b-input type="text" name="price_range" required min=0  value="<?php echo e(old('price_range')); ?>" placeholder="200-500"></b-input>
                      </b-field>
                    </b-field>


                    <b-field label="Division">
                      <b-select placeholder="Select a division" name="division" required>
                        <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($division->id); ?>"><?php echo e($division->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </b-select>

                    </b-field>

                    <b-field label="District">
                      <b-select placeholder="Select a District" name="district" required>
                        <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($district->id); ?>"><?php echo e($district->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </b-select>
                    </b-field>

                  </b-field> <!-- End b-field grouped -->


                  <b-field grouped>

                    <b-field label="Your Phone">
                      
                      <b-field>
                        <b-input type="text" value="<?php echo e(Auth::user()->phone); ?>" name="phone" required></b-input>
                      </b-field>
                    </b-field>

                    <b-field label="Product Category">
                      <b-select placeholder="Select a Category" name="category" required>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </b-select>
                    </b-field>

                    <b-field label="Product Size">
                      <b-select placeholder="Select a Size" name="size" required>
                        <option value="small">Small</option>
                        <option value="medium">Medium</option>
                        <option value="large">Large</option>
                      </b-select>
                    </b-field>

                    <b-field label="Product Brand">
                      <b-select placeholder="Select a Brand" name="brand">
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </b-select>
                    </b-field>

                  </b-field> <!-- End b-field grouped -->



                  <b-field label="Product Description">
                    <b-input type="textarea" id="description" name="description" required  value="Write more about your requestd product (if you want)"></b-input>
                  </b-field>

                  <b-field label="Have you any demo product">
                    <b-input type="file" name="image1" value="<?php echo e(old('image1')); ?>"></b-input>
                  </b-field>


                <div class="field is-grouped m-t-20">
                  <div class="control">
                    <button type="submit" class="button is-primary">Publish Product</button>
                  </div>
                  <div class="control">
                    <a href="<?php echo e(route('index')); ?>" class="button is-danger">Cancel</a>
                  </div>
                </div>

              </section>
            </form>
          </div> <!-- End form card div -->



        </div>
        <div class="column is-4">
          <p class="has-text-centered section-title is-size-3">
            Featured Product
          </p>

          <?php $__empty_1 = true; $__currentLoopData = $featureds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $featured): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="card" onclick="document.location='<?php echo e(route('product.show', $featured->product->slug)); ?>'" style="cursor: pointer">
              <div class="card-image">
                <td>
                  <?php $image = DB::table('product_images')->where('product_id', $featured->product->id)->first(); ?>
                  <img src="<?php echo e(asset("images/products/$image->image")); ?>" alt="R1 5 Latest">
                </td>
              </div>
              <div class="card-content">
                <div class="media">
                  <div class="media-content">
                    <p class="title is-4"><?php echo e($featured->product->title); ?></p>
                    <p class="subtitle is-6"><?php echo e($featured->product->price); ?>৳</p>
                  </div>
                </div>

                <div class="content">
                  Posted <?php echo e(\Carbon\Carbon::parse($featured->product->created_at)->diffForHumans()); ?>

                </div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            
          <?php endif; ?>


        </div>
      </div>
    </div>
  </section>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

  <script src="<?php echo e(asset('js/tinymce/tinymce.min.js')); ?>"></script>
  <script>
  tinymce.init({
    selector:'#description' ,
    // plugins:'link code image imagetools',
    plugins:['autolink lists link image preview hr anchor pagebreak searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime table'],

    toolbar1: ' styleselect | bold italic underline hr link image | bullist numlist | table insert searchreplace undo redo | fontselect  preview code ',
    image_advtab: true,
    menubar:false
  });</script>

  <script>

  const app = new Vue({
    el: '#app',
    data:{
      image: 1,
    },
    methods:{

    }
  });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>