<?php $__env->startSection('content'); ?>



<section class="products">
  <div class="container">
    <div class="columns">
      <div class="column is-3">
        <?php echo $__env->make('partials.product-left-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
      <div class="column is-9">
        <p><a href="<?php echo route('product.request'); ?>" class="button is-primary is-pulled-right m-b-10">Request for a product now</a></p>
        <div class="is-clearfix"></div>


        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="card product-single" onclick="location.href='<?php echo e(route('product.request_products.show', $product->slug)); ?>'">
          <div class="card-content">
            <div class="columns">
              <div class="column is-5">
                <figure class="image">
                  <?php if(($product->image == NULL) || ($product->image == "")): ?>
                    <img src="<?php echo e(asset("images/product_requests/default.png")); ?>" alt="" style="width: 200px;">
                  <?php else: ?>
                    <img src="<?php echo e(asset("images/product_requests/$product->image")); ?>" alt="" style="width: 200px;">
                  <?php endif; ?>

                </figure>
              </div>
              <div class="column is-7">
                <p class="title is-4"><a href="#"><?php echo e($product->title); ?></a></p>
                <p class="subtitle is-5 is-bold has-text-primary button is-warning m-t-0">
                  <?php echo e($product->price_range); ?> ৳
                </p>
                <p class="subtitle is-5">
                  

                  <?php echo e(\Carbon\Carbon::parse($product->created_at)->diffForHumans()); ?>

                </p>
                <p class="has-text-right">
                  <a href="<?php echo e(route('product.show', $product->slug)); ?>" class="button is-large is-warning">
                    <i class="fa fa-cart-plus"></i> &nbsp; Buy this Product
                  </a>
                </p>
              </div>
            </div>

          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="pagination" aria-label="pagination">
          <?php echo e($products->links()); ?>

        </div>

        <?php if($products->count() == 0): ?>
        <b-message title="No Products" type="is-primary" has-icon>
          <h2>Sorry !!!</h2>
          <p>
            There is no product has requested yet !! You can request a product here
          </p>
          <p>
            <a href="<?php echo e(route('product.request')); ?>" class="button is-primary">Request a product Now</a>
          </p>
        </b-message>
        <?php endif; ?>


      </div>
    </div> <!-- End columns -->
  </div> <!-- End container -->



</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
 const app = new Vue({
  el: '#app',
  data:{
  },
  methods:{

  }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>