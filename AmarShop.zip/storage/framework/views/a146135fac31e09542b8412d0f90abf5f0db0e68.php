<?php $__env->startSection('title'); ?>
<?php echo e($user->name); ?> | User Of Amar Shop
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section class="hero">
  <div class="hero-body">
    <div class="container">
      <div class="columns">
        <div class="column is-4">
          <div class="card">
            <div class="card-image">
              <figure class="image is-4by3">
                <?php if(Auth::check()): ?>
                <?php if((Auth::user()->id == $user->id)): ?>
                <button @click="isCardModalActive = true" href="#" class="button is-primary is-small change-button">Change Your Profile Picture</button>
                <?php endif; ?>
                <?php endif; ?>

                <?php $image = md5($user->email); ?>
                <?php if($user->is_company == 1): ?>

                <?php if($user->image == NULL || $user->image == ""): ?>
                
                <img src="<?php echo e(asset('images/companies/default.jpg')); ?>" alt="<?php echo e($user->name); ?>" />
                <?php else: ?>
                <img src='<?php echo e(asset("images/users/$user->image")); ?>' alt="<?php echo e($user->name); ?>" />
                <?php endif; ?>
                <?php else: ?>

                <?php if($user->image == NULL || $user->image == ""): ?>
                <img src="https://www.gravatar.com/avatar/<?php echo e($image); ?>?s=200&r=pg&d=404" alt="<?php echo e($user->name); ?>" />
                <?php else: ?>
                <img src='<?php echo e(asset("images/users/$user->image")); ?>' alt="<?php echo e($user->name); ?>" />
                <?php endif; ?>
                <?php endif; ?>


              </figure>
            </div>
            <div class="card-content">
              <div class="media">
                <div class="media-content">
                  <p class="title is-4"><?php echo e($user->name); ?></p>
                  <p class="subtitle is-6">@<a href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a></p>
                  <p class="button is-success">Trust Point &nbsp; <i class="fa fa-star"></i> &nbsp;<?php echo e($user->trust_point); ?></p>
                  <p>
                    <address>
                      District - <?php echo e($user->district->name); ?> <br />
                      Division - <?php echo e($user->division->name); ?> <br />
                      Street - <?php echo e($user->street_address); ?> <br />
                    </address>
                  </p>
                  <p class="m-t-10"><strong>Contact : </strong> <a href="tel:<?php echo e($user->phone); ?>"><?php echo e($user->phone); ?></a></p>
                  <p><strong>Site : </strong> <a href="<?php echo e($user->website); ?>"><?php echo e($user->website); ?></a></p>
                </div>
              </div>

              <div class="content">
                <time><?php echo e(($user->is_company) ? 'Company' : 'User'); ?> Since - <?php echo e(\Carbon\Carbon::parse($user->created_at)->diffForHumans()); ?> </time>
              </br>
              <?php if(Auth::check()): ?>
                <?php if(Auth::id() == $user->id): ?>
                  <h3 class="is-pulled-left">Shipping Informations</h3>
                  <a href="<?php echo e(route('user.change_shipping_address')); ?>" title="Edit Shipping Informations" class="is-pulled-right button is-info is-outlined">Edit Shipping Informations</a>
                  <div class="is-clearfix">
                    
                  </div>

                <?php endif; ?>
              <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
        <?php if(Auth::check()): ?>
        <b-modal :active.sync="isCardModalActive" :width="640" scroll="keep">

          <div class="card">
            <div class="card-content">
              <div class="content">
                <div class="columns">
                  <div class="column">
                    <h3>Old Profile Picture</h3>
                    <div class="card-image">
                      <figure class="image is-128x128">
                        <?php $image = md5($user->email); ?>
                        <?php if($user->is_company == 1): ?>

                        <?php if($user->image == NULL || $user->image == ""): ?>
                        
                        <img src="<?php echo e(asset('images/companies/default.jpg')); ?>" alt="<?php echo e($user->name); ?>" />
                        <?php else: ?>
                        <img src='<?php echo e(asset("images/users/$user->image")); ?>' alt="<?php echo e($user->name); ?>" />
                        <?php endif; ?>
                        <?php else: ?>

                        <?php if($user->image == NULL || $user->image == ""): ?>
                        <img src="https://www.gravatar.com/avatar/<?php echo e($image); ?>?s=200&r=pg&d=404" alt="<?php echo e($user->name); ?>" />
                        <?php else: ?>
                        <img src='<?php echo e(asset("images/users/$user->image")); ?>' alt="<?php echo e($user->name); ?>" />
                        <?php endif; ?>
                        <?php endif; ?>

                      </figure>
                    </div>
                  </div>
                  <div class="column">
                    <h3>Upload a New Profile Picture</h3>
                    
                    <form action="<?php echo e(route('user.change_profile_picture', Auth::user()->id)); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                      <label for="image">New Image</label>
                      <input type="file" class="input" id="image" name="image">
                      <button type="submit" class="button is-success">Update</button>
                    </form>
                    <button class="button is-danger is-pulled-right" @click="hideModal">Cancel</button>
                  </div>
                </div>
                </div>
              </div>
            </div>
            
          </b-modal>
          <?php endif; ?>



          <div class="column is-8">
            <p class="has-text-right">
              <?php if(Auth::check()): ?>
              <?php if((Auth::user()->id == $user->id)): ?>
              <a href="<?php echo e(route('user.update_profile')); ?>" class="button is-primary is-outlined m-b-5"><i class="fa fa-edit"></i> &nbsp; Edit Your Informations</a>
              <?php endif; ?>
              <?php endif; ?>

            </p>
            <p><?php echo $user->description; ?></p>
            <hr />

            <div class="product-list content">

              <h3>
                <span class="has-text-left is-pulled-left"><?php echo e(($user->is_company == 1) ? 'Our' : 'My'); ?> Latest Products</span>
                <p class="button is-success is-pulled-right">Trust Point &nbsp;<i class="fa fa-star"></i>&nbsp;<?php echo e($user->trust_point); ?></p>
                <?php if(Auth::check()): ?>
                <?php if(Auth::user()->id != $user->id): ?>
                <span class="has-text-right is-pulled-right">
                  <form action="<?php echo e(route('user.trust.change')); ?>" class="form-inline" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="trustee_id" value="<?php echo e($user->id); ?>">
                    <?php if($trust): ?>
                    <b-tooltip label="Already Trusted this <?php echo e(($user->is_company == 1) ? 'Company' : 'User'); ?> ! Click To remove trustness">
                      <button type="submit" class="button is-blueviolet">
                        <i class="fa fa-check"></i> &nbsp; Already Trusted this <?php echo e(($user->is_company == 1) ? 'Company' : 'User'); ?>

                      </button>
                    </b-tooltip>
                    
                    <?php else: ?>
                    <b-tooltip label="Trust this <?php echo e(($user->is_company == 1) ? 'Company' : 'User'); ?> now !!">
                      <button type="submit" class="button is-warning">
                        <i class="fa fa-check"></i> &nbsp; Trust this <?php echo e(($user->is_company == 1) ? 'Company' : 'User'); ?>

                      </button>
                    </b-tooltip>
                    <?php endif; ?>
                  </form>
                  
                  
                </span>
                <?php endif; ?>
                <?php endif; ?>

                <span class="is-clearfix"></span>
                
              </h3>
              <?php
              // $products = App\Product::where('user_id', $user->id)->where('publish_status', 1)->orderBy('id', 'desc')->paginate(20);
              // $products = App\Product::where('user_id', $user->id)->where('publish_status', 1)->orderBy('id', 'desc')->paginate(20);
              $products = $user->products()->paginate(10);
              ?>
              <?php if(Auth::check()): ?>
              <?php if(Auth::user()->id == $user->id): ?>
              <div class="card events-card">
                <header class="card-header">
                  <p class="card-header-title">
                    Manage Products
                    <span class="is-small has-text-grey is-size-7"> &nbsp; (Only you can see this. Other's will see a product list only)</span>
                  </p>
                </header>
                <div class="card-table">
                  <div class="content">
                    <table class="table is-fullwidth is-striped">
                      <thead>
                        <tr>
                          <th width="5%">#</th>
                          <th width="30%">Name</th>
                          <th width="15%">Image</th>
                          <th width="10%">Status</th>
                          <th width="30%">Action</th>
                        </tr>
                      </thead>
                      <tbody>

                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php $i=1; ?>
                        <tr>
                          <td><?php echo e($i); ?></td>
                          <td><?php echo e($product->title); ?></td>
                          <td>
                            <?php $image = DB::table('product_images')->where('product_id', $product->id)->first(); ?>
                            <img src="<?php echo e(asset("images/products/$image->image")); ?>" alt="R1 5 Latest" style="width: 100px;">
                          </td>
                          <td>
                            <form action='<?php echo route('admin.product.change', ["$product->id", 'true']); ?>' method="post" onsubmit="return confirm('Are you sure ? You want to change the status of product .. Once Unpublished, it will be invisible to all..!!')">
                              <?php echo e(csrf_field()); ?>

                              <?php if($product->publish_status == 1): ?>
                              <button type="submit" class="button is-danger">Unpublish</button>
                              <?php else: ?>
                              <button type="submit" class="button is-success">Publish</button>
                              <?php endif; ?>

                            </form>
                          </td>
                          <td>
                            <a href="<?php echo e(route('admin.product.edit', $product->id)); ?>" class="button is-success"><i class="fa fa-pencil"></i></a>
                            <a href="<?php echo e(route('product.show', $product->slug)); ?>" class="button is-info"><i class="fa fa-eye"></i></a>

                            <form onsubmit="return confirm('Are you sure ? Do you want to delete the product ?')" action="<?php echo e(route('admin.product.delete', $product->id)); ?>" class="form-inline" method="POST" >
                              <?php echo e(csrf_field()); ?>

                              <button type="submit" class="button is-danger"><i class="fa fa-trash"></i></button>
                            </form>

                          </td>
                          <?php $i++; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                          <td colspan="4">No Data Here</td>
                        </tr>
                        <?php endif; ?>

                      </tbody>
                    </table>
                  </div>
                </div>
                <footer class="card-footer">
                  <div>
                    <?php echo e($products->links()); ?>

                  </div>
                </footer>
              </div>
              <?php else: ?>
              <?php echo $__env->make('partials.products_list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <?php endif; ?>


              <?php else: ?>
              <?php echo $__env->make('partials.products_list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <?php endif; ?>

            </div>
          </div>
        </div>
      </div>
    </div>
  </section>



  <?php $__env->stopSection(); ?>


  <?php $__env->startSection('scripts'); ?>
  <script>

    const app = new Vue({
      el: '#app',
      data:{
        isCardModalActive: false
      },
      methods:{
        hideModal(){
          this.isCardModalActive = false
        }
      }
    });
  </script>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>