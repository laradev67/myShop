<?php $__env->startSection('stylesheets'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section class="products">
  <div class="container">
    <div class="columns">
      <div class="column is-3">
        <?php echo $__env->make('partials.product-left-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
      <div class="column is-9">

        <div class="card">
          <div class="card-content">
            <div class="columns">



              <?php
                // For Image Slideshow
              $product_images = '';
              $images = DB::table('product_images')->where('product_id', $product->id)->get();
              foreach ($images as $image) {
                $product_images .= "'". asset("images/products/$image->image") ."',";
              }
              ?>

              <div class="column is-5">
                <figure class="image product-image-gallery">
                  <div
                  v-for="number in [currentNumber]"
                  transition="fade"
                  >
                  <img
                  :src="images[Math.abs(currentNumber) % images.length]"
                  v-on:mouseover="stopRotation"
                  v-on:mouseout="startRotation"
                  />
                </div>
                <p class="m-t-30 has-fixed-size">
                  <a class="button is-primary" @click="prev"><i class="fa fa-chevron-left"></i></a>
                  <a class="button is-primary" @click="next"><i class="fa fa-chevron-right"></i></a>
                </p>
              </figure>
            </div>


            <div class="column is-7">
              
                <p class="title is-4 is-pulled-left"><a href="#"><?php echo e($product->title); ?></a></p>
                
                <p class="is-pulled-right">
                  <button class="button is-primary" @click="callPublisher(<?php echo e($product->phone); ?>)"><i class="fa fa-phone"></i></button>
                </p>
                <p class="is-clearfix"></p>
              

              <p class="subtitle is-5 is-bold has-text-primary">
                <?php if($product->offer_price != null): ?>

                <?php
                $now = \Carbon\Carbon::now();
                $expire = $product->offer_expiry_date;
                ?>

                <?php if($now > $expire): ?>
                <span class="has-text-grey-darker"><?php echo e($product->price); ?>৳</span>
                <?php else: ?>
                <span class="button is-danger"><del><?php echo e($product->price); ?>৳</del></span>
                <span class="button is-success"><?php echo e($product->offer_price); ?>৳</span>

                

                <b-tooltip label="Offer Expire last time - <?php echo e(\Carbon\Carbon::parse($product->offer_expiry_date)->diffForHumans()); ?>" type="is-warning" multilined size="is-large">
                 <span class="button is-info"><i class="fa fa-question-circle-o"></i></span>
               </b-tooltip>

               <?php endif; ?>

               <?php endif; ?>


             </p>

             <hr />

             <div class="subtitle is-6">
              <p><strong><i class="fa fa-tags"></i> Category : </strong> <a href="<?php echo e(route('product.category.index', $product->category->slug)); ?>"><?php echo e($product->category->name); ?></a></p>

              <p><strong><i class="fa fa-hdd-o"></i> Brand : </strong> <a href="<?php echo e(route('product.brand.index', $product->brand->slug)); ?>"><?php echo e($product->brand->name); ?></a></p>
              
              <p><strong><i class="fa fa-file"></i> Size : </strong> <?php echo e($product->size); ?></p>
              <hr />
            </div>
            <div>
              <p><strong>Full Features</strong></p>
              <p class="subtitle is-6">
                <?php echo $product->description; ?>

              </p>
              <hr />
            </div>
            <div>
              <p><strong><i class="fa fa-user"></i> Published By : </strong>
                <a href="<?php echo route('user.show', $product->user->username); ?>">

                  <?php if(Auth::check()): ?>
                  <?php if($product->user->id == Auth::user()->id): ?>
                  Me - 
                  <?php endif; ?>
                  <?php endif; ?>
                  <?php echo e($product->user->name); ?>

                  
                </a>
              </p>
              <hr />
            </div>


            <p class="has-text-right">
                  
                <form class="form-inline" action="<?php echo route('wishlist.store'); ?>" method="post">
                  <?php echo e(csrf_field()); ?>

                  <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                  <input type="hidden" name="user_id" value="<?php echo e((Auth::check()) ? Auth::user()->id : ''); ?>">

                  <?php if($wishlist != null): ?>
                  <b-tooltip label="Aleardy Added this product in the wishlist. Click to remove from wishlist.">
                    <button type="submit" class="button is-primary" style="background: blueviolet"><i class="fa fa-heart"></i></button>
                  </b-tooltip>
                  <?php else: ?>
                  <b-tooltip label="Click to add the product in the wishlist !!">
                    <button type="submit" class="button is-primary"><i class="fa fa-heart"></i></button>
                  </b-tooltip>
                  <?php endif; ?>

                </form>


                
            </p>

            <b-modal :active.sync="isComponentModalActive" has-modal-card>
              <modal-form><?php echo $__env->make('components.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></modal-form>
            </b-modal>


          </div>
        </div>

      </div>
    </div>

    <div class="similar-products m-t-30">
      <div class="card">
        <div class="card-header card-header-title">
          <h3>Similar Products</h3>
        </div>
        <div class="card-content">
          <div class="columns">
            <?php $__empty_1 = true; $__currentLoopData = $similar_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <div class="card">
              <div class="card-image">
                <figure class="image is-4by3">
                  <?php $image = DB::table('product_images')->where('product_id', $product->id)->first(); ?>

                  <img src="<?php echo e(asset("images/products/$image->image")); ?>" alt="R1 5 Latest" style="">
                </figure>
              </div>
              <div class="card-content">
                <div class="media">
                  
                  <div class="media-content">
                    <p class="title is-4"><a href="<?php echo e(route('product.show', $product->slug)); ?>" title=""><?php echo e($product->title); ?></a></p>
                    <p class="subtitle is-6 is-font has-text-primary"><?php echo e($product->price); ?>৳</p>
                  </div>
                </div>
              </div>
            </div>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="has-text-danger">No Products has found in this category</p>
            <?php endif; ?>
            

           


          </div>
        </div>
      </div>
    </div>
  </div>
</div> <!-- End columns -->

</div> <!-- End container -->



</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>

  const app = new Vue({
    el: '#app',
    data:{

      isComponentModalActive: false,


      images: [
      <?php echo $product_images; ?>

      ],

      currentNumber: 0,
      timer: null
    },

    ready: function () {
      this.startRotation();
    },

    methods:{


      startRotation: function() {
        this.timer = setInterval(this.next, 3000);
      },

      stopRotation: function() {
        clearTimeout(this.timer);
        this.timer = null;
      },

      next: function() {
        this.currentNumber += 1
      },
      prev: function() {
        this.currentNumber -= 1
      },



      callPublisher(phone){
        this.$dialog.alert({
          title: 'Call Publisher',
          message: 'Call the Publisher Directly To Buy The Product. <br /> <strong>Phone No: </strong> '+phone +'<br /> <a class="button is-primary" href="tel:'+phone+'"><i class="fa fa-phone"></a></a>',
          type: 'is-primary',
          hasIcon: true,
          icon: 'phone',
          confirmText: 'Cancel',
          iconPack: 'fa'
        })
      }
    },

  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>