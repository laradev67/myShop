<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" class="has-navbar-fixed-top">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>
        <?php echo $__env->yieldContent('title', 'Amar Shop | A Place to shop everything, sell everything'); ?>
    </title>
    
    

    <!-- Styles -->
    <link href="<?php echo e(url('css/app.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('stylesheets'); ?>
</head>
<body>
    <div id="app">
        <?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div v-cloak class="m-t-25">
            <div class="has-text-centered loading v-cloak--inline">
                <h1 style="margin-top: 10%; margin-bottom: 10%; background: #fff;">
                  <i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i>
                  <span class="sr-only">Loading...</span>
              </h1>
          </div>
          <div class="v-cloak--hidden">
            <?php echo $__env->make('components.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?> 
            <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>

    
</div>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
