<?php if((Session::has('success')) || ( Session::has('error') )): ?>
<div class="has-text-centered">
  <div class="column is-4 is-offset-4">

    <?php if( Session::has('success') ): ?>
    <b-notification type="is-success">
      <?php echo e(Session::get('success')); ?>

    </b-notification>
    <?php endif; ?>

    <?php if( Session::has('error') ): ?>
    <b-notification type="is-danger">
      <?php echo e(Session::get('error')); ?>

    </b-notification>
    <?php endif; ?>

  </div>
</div>
<?php endif; ?>



<?php if(isset($errors)): ?>
<?php if($errors->any()): ?>
<div class="column is-4 is-offset-4">
  <b-notification type="is-danger" class="has-text-centered">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p><?php echo e($error); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </b-notification>
</div>
<?php endif; ?>

<?php endif; ?>

