<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ShippingAdress extends Model
{
    //
}
