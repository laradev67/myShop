<?php

namespace App\Http\Controllers;

use App\Admin;
use Illuminate\Http\Request;
use Auth;

class BaseController extends Controller
{

    // function __construct(){
    //     echo 'Hei';
    // }


}
