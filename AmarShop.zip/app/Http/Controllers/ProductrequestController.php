<?php

namespace App\Http\Controllers;

use App\Productrequest;
use Illuminate\Http\Request;

class ProductrequestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Productrequest  $productrequest
     * @return \Illuminate\Http\Response
     */
    public function show(Productrequest $productrequest)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Productrequest  $productrequest
     * @return \Illuminate\Http\Response
     */
    public function edit(Productrequest $productrequest)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Productrequest  $productrequest
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Productrequest $productrequest)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Productrequest  $productrequest
     * @return \Illuminate\Http\Response
     */
    public function destroy(Productrequest $productrequest)
    {
        //
    }
}
