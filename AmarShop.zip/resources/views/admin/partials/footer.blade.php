<footer class="footer is-danger">
	<div class="container">
		<div class="content">
			<p class="has-text-centered">
				All rights reserved &copy; 2017 Amar Shop | Admin Panel
			</p>
		</div>
	</div>
</footer>